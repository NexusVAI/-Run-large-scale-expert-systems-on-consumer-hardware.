NeurIPS 2026 Phase 4 Repro Package
=================================

This folder contains the minimal files needed to reproduce the Phase 4 tables and data used in the paper.

Included files
--------------
- requirements.txt
- phase4_prompts.json
- table3_phase4_ppl.csv
- README.txt

Source scripts to include in the zip
------------------------------------
Please copy these Python scripts from the repository root into this package before compressing it:
- run_phase4_extended_safe.py
- run_phase4_lite.py

The authoritative script for the paper tables is:
- run_phase4_extended_safe.py

Model identifiers
-----------------
- Base model: Qwen/Qwen3.5-2B-Base
- Instruct model: Qwen/Qwen3.5-2B

If the models are gated or require acceptance of the license, log in to Hugging Face and accept the model terms first.

Download commands
-----------------
Use Hugging Face CLI and keep the weights outside the zip file:

  huggingface-cli login
  huggingface-cli download Qwen/Qwen3.5-2B-Base --local-dir "Qwen3.5 2B Base" --local-dir-use-symlinks False
  huggingface-cli download Qwen/Qwen3.5-2B --local-dir "Qwen3.5 2B" --local-dir-use-symlinks False

Reproduction steps
------------------
1. Create and activate a Python environment.
2. Install dependencies:

   pip install -r requirements.txt

3. Put the downloaded model folders next to the scripts, or edit the MODEL_PATH_A / MODEL_PATH_B constants in the scripts to point to the downloaded directories.
4. Run the main experiment:

   python -X utf8 -u run_phase4_extended_safe.py > phase4_extended_safe_output_utf8.txt 2>&1

5. Optional smoke test:

   python -X utf8 -u run_phase4_lite.py > phase4_lite_output_utf8.txt 2>&1

Notes
-----
- Do not package model weights in the zip.
- The exact Phase 4 prompts and PPL texts are stored in phase4_prompts.json.
- The Table 3 Phase 4 PPL values extracted from the experiment log are stored in table3_phase4_ppl.csv.
- The runtime logs show Windows UTF-8 output issues, but the numeric results are intact.
