#!/usr/bin/env python3
"""
Cancri Phase 4 Extended — 安全低内存版

特点：
- 父进程只用标准库，不 import torch / transformers
- 所有模型加载与推理都在独立子进程中执行
- 子进程退出后，OS 回收内存，不在父进程中累积碎片
- 扩展到 5 prompts × 20 tokens
- 修正 token match 统计：区分三方一致 / 仅A / 仅B / 都不一致
- 输出每个 prompt 的首次分歧点
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# ============================================================
# 配置
# ============================================================
MODEL_PATH_A = r"D:\a.Qwen3.5系列RoE\Qwen3.5 2B Base"
MODEL_PATH_B = r"D:\a.Qwen3.5系列RoE\Qwen3.5 2B"

MAX_NEW_TOKENS = 20
SPLIT_POINTS = [6]

PROMPTS = [
    "量子计算的基本原理是",
    "The meaning of life is",
    "人工智能未来的发展方向包括",
    "def fibonacci(n):\n    ",
    "在一个遥远的星球上，有一个",
]

PPL_TEXTS = [
    "量子计算是一种利用量子力学原理进行计算的技术。与经典计算机使用比特作为信息的基本单位不同，量子计算机使用量子比特。",
    "Machine learning is a subset of artificial intelligence that focuses on building systems that learn from data rather than being explicitly programmed.",
    "深度学习是机器学习的一个分支，它使用多层神经网络来学习数据的层次化表示。卷积神经网络在图像识别领域取得了巨大成功。",
]

# 运行时轻微等待，降低 Windows 上的页面文件压力
CHILD_SETTLE_SECONDS = 2


# ============================================================
# 子进程：所有 torch/transformers 只在这里导入
# ============================================================

def _child_main() -> None:
    import gc
    import math

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    def trim_memory() -> None:
        gc.collect()
        try:
            import ctypes

            ctypes.windll.psapi.EmptyWorkingSet(ctypes.windll.kernel32.GetCurrentProcess())
        except Exception:
            pass

    def load_model(path: str):
        tok = AutoTokenizer.from_pretrained(path, trust_remote_code=True)
        if tok.pad_token_id is None and tok.eos_token_id is not None:
            tok.pad_token = tok.eos_token
        mdl = AutoModelForCausalLM.from_pretrained(
            path,
            dtype=torch.float32,
            device_map="cpu",
            trust_remote_code=True,
            low_cpu_mem_usage=True,
        )
        mdl.eval()
        try:
            mdl.config.use_cache = False
        except Exception:
            pass
        return mdl, tok

    stage = os.environ["PHASE4_CHILD_STAGE"]
    in_path = os.environ["PHASE4_IN"]
    out_path = os.environ["PHASE4_OUT"]

    with open(in_path, "r", encoding="utf-8") as f:
        params = json.load(f)

    result: dict = {}

    # ── generate_sequence ──────────────────────────────────
    if stage == "generate_sequence":
        model_path = params["model_path"]
        prompt_text = params["prompt_text"]
        max_tokens = int(params["max_tokens"])

        mdl, tok = load_model(model_path)
        try:
            with torch.inference_mode():
                ids = tok(prompt_text, return_tensors="pt")["input_ids"]
                gen = ids.clone()
                new_token_ids: list[int] = []
                new_token_texts: list[str] = []

                for _ in range(max_tokens):
                    logits = mdl(input_ids=gen).logits
                    next_id = logits[0, -1, :].argmax().item()
                    new_token_ids.append(int(next_id))
                    new_token_texts.append(tok.decode([next_id], skip_special_tokens=True))
                    gen = torch.cat([gen, torch.tensor([[next_id]], dtype=torch.long)], dim=1)
                    if next_id == tok.eos_token_id:
                        break

                result = {
                    "generated_ids": gen[0].tolist(),
                    "prompt_len": int(ids.shape[1]),
                    "decoded_text": tok.decode(gen[0], skip_special_tokens=True),
                    "new_token_ids": new_token_ids,
                    "new_token_texts": new_token_texts,
                }
        finally:
            if "mdl" in locals():
                del mdl
            if "tok" in locals():
                del tok
            if "ids" in locals():
                del ids
            if "gen" in locals():
                del gen
            if "logits" in locals():
                del logits
            trim_memory()

    # ── relay_one_token ────────────────────────────────────
    elif stage == "relay_one_token":
        input_ids_list = params["input_ids"]
        split = int(params["split"])
        relay_dir = params["relay_dir"]
        relay_file = os.path.join(relay_dir, "_relay.pt")

        # A 阶段
        mdl_a, tok_a = load_model(MODEL_PATH_A)
        try:
            with torch.inference_mode():
                input_ids = torch.tensor([input_ids_list], dtype=torch.long)
                inner = mdl_a.model
                hidden = inner.embed_tokens(input_ids)
                pos_ids = torch.arange(input_ids.shape[1]).unsqueeze(0)
                rope = inner.rotary_emb(hidden, pos_ids)
                for i in range(split):
                    layer_out = inner.layers[i](hidden, rope, attention_mask=None)
                    hidden = layer_out[0] if isinstance(layer_out, tuple) else layer_out
                torch.save({"hidden": hidden.cpu(), "seq_len": int(input_ids.shape[1])}, relay_file)
        finally:
            if "mdl_a" in locals():
                del mdl_a
            if "tok_a" in locals():
                del tok_a
            if "inner" in locals():
                del inner
            if "hidden" in locals():
                del hidden
            if "pos_ids" in locals():
                del pos_ids
            if "rope" in locals():
                del rope
            trim_memory()
            time.sleep(CHILD_SETTLE_SECONDS)

        # B 阶段
        mdl_b, tok_b = load_model(MODEL_PATH_B)
        try:
            with torch.inference_mode():
                relay = torch.load(relay_file, weights_only=True)
                hidden = relay["hidden"]
                inner = mdl_b.model
                total = len(inner.layers)
                pos_ids = torch.arange(relay["seq_len"]).unsqueeze(0)
                rope = inner.rotary_emb(hidden, pos_ids)
                for i in range(split, total):
                    layer_out = inner.layers[i](hidden, rope, attention_mask=None)
                    hidden = layer_out[0] if isinstance(layer_out, tuple) else layer_out
                hidden = inner.norm(hidden)
                logits = mdl_b.lm_head(hidden)
                next_id = int(logits[0, -1, :].argmax().item())
                top5_vals, top5_ids = torch.topk(logits[0, -1, :], 5)
                top5 = [[int(i), float(v)] for i, v in zip(top5_ids, top5_vals)]
                result = {
                    "next_id": next_id,
                    "next_text": tok_b.decode([next_id], skip_special_tokens=True),
                    "top5": top5,
                }
        finally:
            if "mdl_b" in locals():
                del mdl_b
            if "tok_b" in locals():
                del tok_b
            if "relay" in locals():
                del relay
            if "hidden" in locals():
                del hidden
            if "inner" in locals():
                del inner
            if "pos_ids" in locals():
                del pos_ids
            if "rope" in locals():
                del rope
            if "logits" in locals():
                del logits
            trim_memory()

    # ── pure_ppl ───────────────────────────────────────────
    elif stage == "pure_ppl":
        model_path = params["model_path"]
        text = params["text"]

        mdl, tok = load_model(model_path)
        try:
            with torch.inference_mode():
                ids = tok(text, return_tensors="pt")["input_ids"]
                logits = mdl(input_ids=ids).logits
        finally:
            if "mdl" in locals():
                del mdl
            if "tok" in locals():
                del tok
            trim_memory()

        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = ids[:, 1:].contiguous()
        loss = torch.nn.CrossEntropyLoss()(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
        )
        result = {"ppl": float(math.exp(loss.item()))}

        del logits, shift_logits, shift_labels, ids
        trim_memory()

    # ── relay_ppl ──────────────────────────────────────────
    elif stage == "relay_ppl":
        text = params["text"]
        split = int(params["split"])
        relay_dir = params["relay_dir"]
        relay_file = os.path.join(relay_dir, "_ppl_relay.pt")

        # 先只加载 tokenizer 做分词
        tok = AutoTokenizer.from_pretrained(MODEL_PATH_A, trust_remote_code=True)
        if tok.pad_token_id is None and tok.eos_token_id is not None:
            tok.pad_token = tok.eos_token
        ids = tok(text, return_tensors="pt")["input_ids"]
        del tok
        trim_memory()

        # A 阶段
        mdl_a, _ = load_model(MODEL_PATH_A)
        try:
            with torch.inference_mode():
                inner = mdl_a.model
                hidden = inner.embed_tokens(ids)
                pos_ids = torch.arange(ids.shape[1]).unsqueeze(0)
                rope = inner.rotary_emb(hidden, pos_ids)
                for i in range(split):
                    layer_out = inner.layers[i](hidden, rope, attention_mask=None)
                    hidden = layer_out[0] if isinstance(layer_out, tuple) else layer_out
                torch.save({"hidden": hidden.cpu(), "seq_len": int(ids.shape[1])}, relay_file)
        finally:
            if "mdl_a" in locals():
                del mdl_a
            if "inner" in locals():
                del inner
            if "hidden" in locals():
                del hidden
            if "pos_ids" in locals():
                del pos_ids
            if "rope" in locals():
                del rope
            trim_memory()
            time.sleep(CHILD_SETTLE_SECONDS)

        # B 阶段
        mdl_b, _ = load_model(MODEL_PATH_B)
        try:
            with torch.inference_mode():
                relay = torch.load(relay_file, weights_only=True)
                hidden = relay["hidden"]
                inner = mdl_b.model
                total = len(inner.layers)
                pos_ids = torch.arange(relay["seq_len"]).unsqueeze(0)
                rope = inner.rotary_emb(hidden, pos_ids)
                for i in range(split, total):
                    layer_out = inner.layers[i](hidden, rope, attention_mask=None)
                    hidden = layer_out[0] if isinstance(layer_out, tuple) else layer_out
                hidden = inner.norm(hidden)
                logits = mdl_b.lm_head(hidden)
        finally:
            if "mdl_b" in locals():
                del mdl_b
            if "relay" in locals():
                del relay
            if "inner" in locals():
                del inner
            if "pos_ids" in locals():
                del pos_ids
            if "rope" in locals():
                del rope
            trim_memory()

        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = ids[:, 1:].contiguous()
        loss = torch.nn.CrossEntropyLoss()(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
        )
        result = {"ppl": float(math.exp(loss.item()))}

        del hidden, logits, shift_logits, shift_labels, ids
        trim_memory()

    else:
        raise ValueError(f"Unknown stage: {stage}")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False)


# ============================================================
# 父进程：纯 stdlib 调度器
# ============================================================

def sep(title: str, char: str = "═") -> None:
    print(f"\n{char * 60}")
    print(f"  {title}")
    print(f"{char * 60}")


def short_text(text: str, limit: int = 32) -> str:
    s = text.replace("\n", "\\n").replace("\r", "\\r")
    if len(s) > limit:
        s = s[:limit - 1] + "…"
    return s


def call_child(stage: str, params: dict, work_dir: str) -> dict:
    ts = time.time_ns()
    in_path = os.path.join(work_dir, f"{stage}_{ts}_in.json")
    out_path = os.path.join(work_dir, f"{stage}_{ts}_out.json")

    with open(in_path, "w", encoding="utf-8") as f:
        json.dump(params, f, ensure_ascii=False)

    env = os.environ.copy()
    env["PHASE4_CHILD_STAGE"] = stage
    env["PHASE4_IN"] = in_path
    env["PHASE4_OUT"] = out_path

    proc = subprocess.run(
        [sys.executable, "-X", "utf8", "-u", str(Path(__file__).resolve())],
        env=env,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"child '{stage}' failed (exit {proc.returncode})")

    with open(out_path, "r", encoding="utf-8") as f:
        return json.load(f)


def step1_generation(work_dir: str) -> list[dict]:
    sep(f"Step 1: 多 Token 接力生成（{MAX_NEW_TOKENS} tokens × {len(PROMPTS)} prompts）")
    all_results: list[dict] = []

    for pi, prompt in enumerate(PROMPTS):
        print(f"\n  {'─' * 60}")
        print(f"  [{pi + 1}/{len(PROMPTS)}] Prompt: '{prompt}'")

        # 纯 A
        print("    生成 纯A...", end="", flush=True)
        t0 = time.time()
        res_a = call_child(
            "generate_sequence",
            {"model_path": MODEL_PATH_A, "prompt_text": prompt, "max_tokens": MAX_NEW_TOKENS},
            work_dir,
        )
        print(f" ({time.time() - t0:.0f}s)")
        print(f"    纯A: {res_a['decoded_text']}")

        # 纯 B
        print("    生成 纯B...", end="", flush=True)
        t0 = time.time()
        res_b = call_child(
            "generate_sequence",
            {"model_path": MODEL_PATH_B, "prompt_text": prompt, "max_tokens": MAX_NEW_TOKENS},
            work_dir,
        )
        print(f" ({time.time() - t0:.0f}s)")
        print(f"    纯B: {res_b['decoded_text']}")

        prompt_len = int(res_a["prompt_len"])
        a_new_ids = res_a["new_token_ids"]
        b_new_ids = res_b["new_token_ids"]
        a_new_texts = res_a["new_token_texts"]
        b_new_texts = res_b["new_token_texts"]

        # 接力
        for split in SPLIT_POINTS:
            print(f"    生成 接力@{split}...", end="", flush=True)
            t0 = time.time()
            current_ids = res_a["generated_ids"][:prompt_len]
            per_token_log: list[dict] = []
            first_div_a = -1
            first_div_b = -1

            for step in range(MAX_NEW_TOKENS):
                res_r = call_child(
                    "relay_one_token",
                    {"input_ids": current_ids, "split": split, "relay_dir": work_dir},
                    work_dir,
                )
                nid_r = int(res_r["next_id"])
                text_r = res_r["next_text"]
                current_ids = current_ids + [nid_r]

                tok_a = a_new_ids[step] if step < len(a_new_ids) else -1
                tok_b = b_new_ids[step] if step < len(b_new_ids) else -1
                text_a = a_new_texts[step] if step < len(a_new_texts) else "?"
                text_b = b_new_texts[step] if step < len(b_new_texts) else "?"

                if first_div_a < 0 and nid_r != tok_a:
                    first_div_a = step
                if first_div_b < 0 and nid_r != tok_b:
                    first_div_b = step

                if nid_r == tok_a and nid_r == tok_b:
                    match = "BOTH"
                elif nid_r == tok_a:
                    match = "A_only"
                elif nid_r == tok_b:
                    match = "B_only"
                else:
                    match = "NEITHER"

                per_token_log.append(
                    {
                        "step": step,
                        "relay_id": nid_r,
                        "relay_text": text_r,
                        "a_id": tok_a,
                        "a_text": text_a,
                        "b_id": tok_b,
                        "b_text": text_b,
                        "match": match,
                    }
                )

            time_r = time.time() - t0
            print(f" ({time_r:.0f}s)")
            print(f"    接力@{split}: {short_text(''.join(x['relay_text'] for x in per_token_log))}")

            n_both = sum(1 for x in per_token_log if x["match"] == "BOTH")
            n_a_only = sum(1 for x in per_token_log if x["match"] == "A_only")
            n_b_only = sum(1 for x in per_token_log if x["match"] == "B_only")
            n_neither = sum(1 for x in per_token_log if x["match"] == "NEITHER")

            print(
                f"             tokens={len(per_token_log)}  "
                f"tri_eq={n_both}  A_only={n_a_only}  B_only={n_b_only}  neither={n_neither}"
            )
            print(f"             first_div_A=step{first_div_a if first_div_a >= 0 else '>'+str(len(per_token_log))}")
            print(f"             first_div_B=step{first_div_b if first_div_b >= 0 else '>'+str(len(per_token_log))}")
            print("             逐 token (前 20 全量):")
            for entry in per_token_log:
                s = entry["step"]
                print(
                    f"               step{s:02d}: relay='{short_text(entry['relay_text'], 12)}'  "
                    f"A='{short_text(entry['a_text'], 12)}'  "
                    f"B='{short_text(entry['b_text'], 12)}'  -> {entry['match']}"
                )

            all_results.append(
                {
                    "prompt": prompt,
                    "split": split,
                    "tri_eq": n_both,
                    "a_only": n_a_only,
                    "b_only": n_b_only,
                    "neither": n_neither,
                    "total": len(per_token_log),
                    "first_div_a": first_div_a,
                    "first_div_b": first_div_b,
                    "per_token": per_token_log,
                    "text_a": res_a["decoded_text"],
                    "text_b": res_b["decoded_text"],
                }
            )

    sep("Step 1 汇总: Token 匹配率")
    print(f"  {'Split':>6s}  {'tri_eq%':>10s}  {'A_only%':>10s}  {'B_only%':>10s}  {'neither%':>10s}")
    print(f"  {'─' * 60}")
    for split in SPLIT_POINTS:
        entries = [r for r in all_results if r["split"] == split]
        total = sum(e["total"] for e in entries)
        tri = sum(e["tri_eq"] for e in entries)
        a_only = sum(e["a_only"] for e in entries)
        b_only = sum(e["b_only"] for e in entries)
        neither = sum(e["neither"] for e in entries)
        print(
            f"  {split:>6d}  {tri / max(total, 1):>10.1%}  {a_only / max(total, 1):>10.1%}  {b_only / max(total, 1):>10.1%}  {neither / max(total, 1):>10.1%}"
        )

    return all_results


def step2_ppl(work_dir: str) -> list[dict]:
    sep("Step 2: PPL 评估（长文本 Teacher Forcing）")
    print(f"  splits: {SPLIT_POINTS}\n")

    ppl_results: list[dict] = []
    for idx, text in enumerate(PPL_TEXTS):
        short = text[:48] + ("..." if len(text) > 48 else "")
        print(f"  '{short}'")

        print("    PPL_A...", end="", flush=True)
        ppl_a = call_child("pure_ppl", {"model_path": MODEL_PATH_A, "text": text}, work_dir)["ppl"]
        print(f" {ppl_a:.2f}")

        print("    PPL_B...", end="", flush=True)
        ppl_b = call_child("pure_ppl", {"model_path": MODEL_PATH_B, "text": text}, work_dir)["ppl"]
        print(f" {ppl_b:.2f}")

        for split in SPLIT_POINTS:
            print(f"    PPL_R@{split}...", end="", flush=True)
            ppl_r = call_child(
                "relay_ppl",
                {"text": text, "split": split, "relay_dir": work_dir},
                work_dir,
            )["ppl"]
            best = min(ppl_a, ppl_b)
            ratio_best = ppl_r / best
            ratio_b = ppl_r / ppl_b
            status = "✅" if ratio_best < 1.5 else "⚠️" if ratio_best < 3.0 else "❌"
            print(f" {ppl_r:.2f}  ratio_vs_best={ratio_best:.3f}  ratio_vs_B={ratio_b:.3f}  {status}")
            ppl_results.append(
                {
                    "text": text,
                    "split": split,
                    "ppl_a": ppl_a,
                    "ppl_b": ppl_b,
                    "ppl_r": ppl_r,
                    "ratio_best": ratio_best,
                    "ratio_b": ratio_b,
                }
            )
        print()

    return ppl_results


def step3_divergence_summary(step1_results: list[dict]) -> None:
    sep("Step 3: 首 Token 分歧点分析")
    print("  说明: 这里直接复用 Step 1 的逐 token 结果，不额外增加模型加载次数\n")

    for r in step1_results:
        prompt = r["prompt"]
        split = r["split"]
        div_a = r["first_div_a"]
        div_b = r["first_div_b"]
        total = r["total"]
        div_a_s = f"step{div_a}" if div_a >= 0 else f">{total}"
        div_b_s = f"step{div_b}" if div_b >= 0 else f">{total}"
        print(f"  Prompt: '{prompt}'")
        print(f"    split@{split}: first_div_A={div_a_s}  first_div_B={div_b_s}")
        print()


def main() -> None:
    sep("Cancri Phase 4 Extended — 安全低内存版", "█")

    print(
        f"""
  配置:
    A: {os.path.basename(MODEL_PATH_A)}
    B: {os.path.basename(MODEL_PATH_B)}
    Max tokens: {MAX_NEW_TOKENS}
    Splits: {SPLIT_POINTS}
    Prompts: {len(PROMPTS)}

  策略: 父进程零 torch / transformers 依赖
        所有模型操作在独立子进程中执行
        子进程退出后内存由 OS 完全回收
"""
    )

    work_dir = tempfile.mkdtemp(prefix="phase4_extsafe_")
    print(f"  work_dir: {work_dir}")

    t_total = time.time()

    # Step 1
    t0 = time.time()
    step1_results = step1_generation(work_dir)
    print(f"\n  Step 1 耗时: {time.time() - t0:.0f}s")

    # Step 2
    t0 = time.time()
    ppl_results = step2_ppl(work_dir)
    print(f"\n  Step 2 耗时: {time.time() - t0:.0f}s")

    # Step 3
    t0 = time.time()
    step3_divergence_summary(step1_results)
    print(f"  Step 3 耗时: {time.time() - t0:.0f}s")

    # 总结
    sep("Phase 4 Extended 最终汇总")
    total_time = time.time() - t_total
    total_tok = sum(r["total"] for r in step1_results)
    tri_eq = sum(r["tri_eq"] for r in step1_results)
    a_only = sum(r["a_only"] for r in step1_results)
    b_only = sum(r["b_only"] for r in step1_results)
    neither = sum(r["neither"] for r in step1_results)

    avg_ratio_best = sum(r["ratio_best"] for r in ppl_results) / max(len(ppl_results), 1)
    avg_ratio_b = sum(r["ratio_b"] for r in ppl_results) / max(len(ppl_results), 1)

    print(
        f"""
  总耗时: {total_time:.0f}s ({total_time/60:.1f}min)
  Split: {SPLIT_POINTS}

  Token 匹配总计:
    三方一致:  {tri_eq}/{total_tok} ({tri_eq / max(total_tok, 1):.1%})
    仅匹配A:   {a_only}/{total_tok} ({a_only / max(total_tok, 1):.1%})
    仅匹配B:   {b_only}/{total_tok} ({b_only / max(total_tok, 1):.1%})
    都不匹配:  {neither}/{total_tok} ({neither / max(total_tok, 1):.1%})

  PPL 平均比值:
    avg_ratio_vs_best = {avg_ratio_best:.3f}
    avg_ratio_vs_B    = {avg_ratio_b:.3f}

  Cancri 完整验证链:

  Phase 0   签名探测                ✅
  Phase 1   同模型分层验证          ✅  0.00e+00
  Phase 2   同模型张量接力          ✅  bitwise identical
  Phase 3a  同权重双实例接力        ✅  bitwise identical
  Phase 3a+ 全切分点扫描            ✅  25/25 pass
  Phase 3b  异权重接力(单步)        ✅  PPL ratio 0.95~1.17
  Phase 4s  异权重 5-token          ✅  已完成
  Phase 4e  异权重 20-token         ← 本次实验

  请把以上完整输出复制发给我
"""
    )


if __name__ == "__main__":
    if "PHASE4_CHILD_STAGE" in os.environ:
        _child_main()
    else:
        main()
