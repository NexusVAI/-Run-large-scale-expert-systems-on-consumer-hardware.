#!/usr/bin/env python3
"""
Cancri Phase 4 Lite — 极限低内存版

父进程不 import torch / transformers，只用 subprocess + json 调度。
每次只有一个子进程持有模型，子进程退出后内存被 OS 完全回收。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# ============================================================
# 配置（父子进程共享）
# ============================================================
MODEL_PATH_A = r"D:\a.Qwen3.5系列RoE\Qwen3.5 2B Base"
MODEL_PATH_B = r"D:\a.Qwen3.5系列RoE\Qwen3.5 2B"

MAX_NEW_TOKENS = 5
SPLIT_POINTS = [6]
PROMPTS = [
    "量子计算的基本原理是",
]

PPL_TEXTS = [
    "量子计算是一种利用量子力学原理进行计算的技术。与经典计算机使用比特作为信息的基本单位不同，量子计算机使用量子比特。",
]


# ############################################################
#  以下是子进程专用代码（只在 PHASE4_CHILD_STAGE 被设置时执行）
# ############################################################

def _child_main() -> None:
    """子进程入口 —— 这里才 import torch"""
    import gc
    import math

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    def trim():
        gc.collect()
        try:
            import ctypes
            ctypes.windll.psapi.EmptyWorkingSet(
                ctypes.windll.kernel32.GetCurrentProcess()
            )
        except Exception:
            pass

    def load_model(path):
        tok = AutoTokenizer.from_pretrained(path, trust_remote_code=True)
        if tok.pad_token_id is None and tok.eos_token_id is not None:
            tok.pad_token = tok.eos_token
        mdl = AutoModelForCausalLM.from_pretrained(
            path,
            dtype=torch.float32,
            device_map="cpu",
            trust_remote_code=True,
            low_cpu_mem_usage=True,
        )
        mdl.eval()
        try:
            mdl.config.use_cache = False
        except Exception:
            pass
        return mdl, tok

    stage = os.environ["PHASE4_CHILD_STAGE"]
    in_path = os.environ["PHASE4_IN"]
    out_path = os.environ["PHASE4_OUT"]

    with open(in_path, "r", encoding="utf-8") as f:
        params = json.load(f)

    # ── generate_sequence ──────────────────────────────────
    if stage == "generate_sequence":
        model_path = params["model_path"]
        prompt_text = params["prompt_text"]
        max_tokens = params["max_tokens"]

        mdl, tok = load_model(model_path)
        with torch.inference_mode():
            ids = tok(prompt_text, return_tensors="pt")["input_ids"]
            gen = ids.clone()
            for _ in range(max_tokens):
                logits = mdl(input_ids=gen).logits
                nid = logits[0, -1, :].argmax().item()
                gen = torch.cat(
                    [gen, torch.tensor([[nid]], dtype=torch.long)], dim=1
                )
                if nid == tok.eos_token_id:
                    break
        result = {
            "generated_ids": gen[0].tolist(),
            "decoded_text": tok.decode(gen[0], skip_special_tokens=True),
            "prompt_len": ids.shape[1],
        }
        del mdl, tok, gen, ids
        if "logits" in locals():
            del logits
        trim()

    # ── relay_one_token ────────────────────────────────────
    elif stage == "relay_one_token":
        input_ids_list = params["input_ids"]
        split = params["split"]
        relay_dir = params["relay_dir"]
        relay_file = os.path.join(relay_dir, "_relay.pt")

        # A 阶段
        mdl_a, _ = load_model(MODEL_PATH_A)
        with torch.inference_mode():
            input_ids = torch.tensor([input_ids_list], dtype=torch.long)
            inner = mdl_a.model
            hidden = inner.embed_tokens(input_ids)
            pos_ids = torch.arange(input_ids.shape[1]).unsqueeze(0)
            rope = inner.rotary_emb(hidden, pos_ids)
            for i in range(split):
                lo = inner.layers[i](hidden, rope, attention_mask=None)
                hidden = lo[0] if isinstance(lo, tuple) else lo
            torch.save({"hidden": hidden.cpu(), "seq_len": input_ids.shape[1]}, relay_file)
        del mdl_a, inner, hidden, pos_ids, rope
        trim()
        time.sleep(2)

        # B 阶段
        mdl_b, _ = load_model(MODEL_PATH_B)
        with torch.inference_mode():
            relay = torch.load(relay_file, weights_only=True)
            hidden = relay["hidden"]
            inner = mdl_b.model
            total = len(inner.layers)
            pos_ids = torch.arange(relay["seq_len"]).unsqueeze(0)
            rope = inner.rotary_emb(hidden, pos_ids)
            for i in range(split, total):
                lo = inner.layers[i](hidden, rope, attention_mask=None)
                hidden = lo[0] if isinstance(lo, tuple) else lo
            hidden = inner.norm(hidden)
            logits = mdl_b.lm_head(hidden)
            nid = logits[0, -1, :].argmax().item()
            top5_v, top5_i = torch.topk(logits[0, -1, :], 5)
            top5 = [[int(i), float(v)] for i, v in zip(top5_i, top5_v)]
        result = {"next_id": nid, "top5": top5}
        del mdl_b, relay, hidden, inner, pos_ids, rope, logits
        trim()

    # ── pure_ppl ───────────────────────────────────────────
    elif stage == "pure_ppl":
        model_path = params["model_path"]
        text = params["text"]

        mdl, tok = load_model(model_path)
        with torch.inference_mode():
            ids = tok(text, return_tensors="pt")["input_ids"]
            logits = mdl(input_ids=ids).logits
        del mdl, tok
        trim()

        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = ids[:, 1:].contiguous()
        loss = torch.nn.CrossEntropyLoss()(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
        )
        result = {"ppl": float(math.exp(loss.item()))}
        del logits, shift_logits, shift_labels, ids
        trim()

    # ── relay_ppl ──────────────────────────────────────────
    elif stage == "relay_ppl":
        text = params["text"]
        split = params["split"]
        relay_dir = params["relay_dir"]
        relay_file = os.path.join(relay_dir, "_ppl_relay.pt")

        # tokenize (need tokenizer briefly)
        tok = AutoTokenizer.from_pretrained(MODEL_PATH_A, trust_remote_code=True)
        ids = tok(text, return_tensors="pt")["input_ids"]
        del tok

        # A 阶段
        mdl_a, _ = load_model(MODEL_PATH_A)
        with torch.inference_mode():
            inner = mdl_a.model
            hidden = inner.embed_tokens(ids)
            pos_ids = torch.arange(ids.shape[1]).unsqueeze(0)
            rope = inner.rotary_emb(hidden, pos_ids)
            for i in range(split):
                lo = inner.layers[i](hidden, rope, attention_mask=None)
                hidden = lo[0] if isinstance(lo, tuple) else lo
            torch.save({"hidden": hidden.cpu(), "seq_len": ids.shape[1]}, relay_file)
        del mdl_a, inner, hidden, pos_ids, rope
        trim()
        time.sleep(2)

        # B 阶段
        mdl_b, _ = load_model(MODEL_PATH_B)
        with torch.inference_mode():
            relay = torch.load(relay_file, weights_only=True)
            hidden = relay["hidden"]
            inner = mdl_b.model
            total = len(inner.layers)
            pos_ids = torch.arange(relay["seq_len"]).unsqueeze(0)
            rope = inner.rotary_emb(hidden, pos_ids)
            for i in range(split, total):
                lo = inner.layers[i](hidden, rope, attention_mask=None)
                hidden = lo[0] if isinstance(lo, tuple) else lo
            hidden = inner.norm(hidden)
            logits = mdl_b.lm_head(hidden)
        del mdl_b, relay, inner, pos_ids, rope
        trim()

        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = ids[:, 1:].contiguous()
        loss = torch.nn.CrossEntropyLoss()(
            shift_logits.view(-1, shift_logits.size(-1)),
            shift_labels.view(-1),
        )
        result = {"ppl": float(math.exp(loss.item()))}
        del hidden, logits, shift_logits, shift_labels, ids
        trim()

    else:
        raise ValueError(f"Unknown stage: {stage}")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False)


# ############################################################
#  以下是父进程代码（纯 stdlib，零 torch 依赖）
# ############################################################

def sep(title: str, char: str = "═") -> None:
    print(f"\n{char * 60}")
    print(f"  {title}")
    print(f"{char * 60}")


def call_child(stage: str, params: dict, work_dir: str) -> dict:
    """启动子进程执行一个 stage，返回 JSON 结果"""
    ts = time.time_ns()
    in_path = os.path.join(work_dir, f"{stage}_{ts}_in.json")
    out_path = os.path.join(work_dir, f"{stage}_{ts}_out.json")

    with open(in_path, "w", encoding="utf-8") as f:
        json.dump(params, f, ensure_ascii=False)

    env = os.environ.copy()
    env["PHASE4_CHILD_STAGE"] = stage
    env["PHASE4_IN"] = in_path
    env["PHASE4_OUT"] = out_path

    proc = subprocess.run(
        [sys.executable, "-X", "utf8", "-u", str(Path(__file__).resolve())],
        env=env,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"child '{stage}' failed (exit {proc.returncode})"
        )

    with open(out_path, "r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    sep("Cancri Phase 4 Lite — 极限低内存版", "█")
    print(f"""
  配置:
    A: {os.path.basename(MODEL_PATH_A)}
    B: {os.path.basename(MODEL_PATH_B)}
    Max tokens: {MAX_NEW_TOKENS}
    Splits: {SPLIT_POINTS}
    Prompts: {len(PROMPTS)}

  策略: 父进程零 torch 依赖，所有模型操作在独立子进程中执行
        子进程退出后内存被 OS 完全回收
""")

    work_dir = tempfile.mkdtemp(prefix="phase4_lite_")
    print(f"  work_dir: {work_dir}")
    t_total = time.time()

    # ================================================================
    #  Step 1: 多 token 接力生成
    # ================================================================
    sep(f"Step 1: 多 Token 接力生成（{MAX_NEW_TOKENS} tokens × {len(PROMPTS)} prompts）")
    all_results = []

    for pi, prompt in enumerate(PROMPTS):
        print(f"\n  {'─' * 55}")
        print(f"  [{pi+1}/{len(PROMPTS)}] Prompt: '{prompt}'")

        # ── 纯 A ──
        print(f"    生成 纯A...", end="", flush=True)
        t0 = time.time()
        res_a = call_child("generate_sequence", {
            "model_path": MODEL_PATH_A,
            "prompt_text": prompt,
            "max_tokens": MAX_NEW_TOKENS,
        }, work_dir)
        print(f" ({time.time()-t0:.0f}s)")
        print(f"    纯A: {res_a['decoded_text']}")
        time.sleep(3)

        # ── 纯 B ──
        print(f"    生成 纯B...", end="", flush=True)
        t0 = time.time()
        res_b = call_child("generate_sequence", {
            "model_path": MODEL_PATH_B,
            "prompt_text": prompt,
            "max_tokens": MAX_NEW_TOKENS,
        }, work_dir)
        print(f" ({time.time()-t0:.0f}s)")
        print(f"    纯B: {res_b['decoded_text']}")
        time.sleep(3)

        prompt_len = res_a["prompt_len"]
        a_new = res_a["generated_ids"][prompt_len:]
        b_new = res_b["generated_ids"][prompt_len:]

        # ── 接力生成 ──
        for split in SPLIT_POINTS:
            print(f"    生成 接力@{split}...", end="", flush=True)
            t0 = time.time()
            current_ids = res_a["generated_ids"][:prompt_len]  # prompt tokens
            per_token_log = []

            for step in range(MAX_NEW_TOKENS):
                print(f"t{step}", end="", flush=True)
                res_r = call_child("relay_one_token", {
                    "input_ids": current_ids,
                    "split": split,
                    "relay_dir": work_dir,
                }, work_dir)
                nid_r = res_r["next_id"]
                current_ids = current_ids + [nid_r]

                tok_a = a_new[step] if step < len(a_new) else -1
                tok_b = b_new[step] if step < len(b_new) else -1
                match = "A" if nid_r == tok_a else ("B" if nid_r == tok_b else "X")
                per_token_log.append({
                    "step": step, "relay": nid_r,
                    "a": tok_a, "b": tok_b, "match": match,
                })
                time.sleep(2)

            time_r = time.time() - t0
            relay_new = current_ids[prompt_len:]
            print(f" ({time_r:.0f}s)")
            print(f"    接力@{split} token IDs: {relay_new}")

            n_total = len(per_token_log)
            n_match_a = sum(1 for x in per_token_log if x["match"] == "A")
            n_match_b = sum(1 for x in per_token_log if x["match"] == "B")
            n_match_x = sum(1 for x in per_token_log if x["match"] == "X")
            print(
                f"             tokens={n_total}  "
                f"match_A={n_match_a}  match_B={n_match_b}  "
                f"unique={n_match_x}"
            )
            for entry in per_token_log:
                s = entry["step"]
                m = entry["match"]
                print(f"               step{s}: relay={entry['relay']}  A={entry['a']}  B={entry['b']}  -> {m}")

            all_results.append({
                "prompt": prompt, "split": split,
                "match_a": n_match_a, "match_b": n_match_b,
                "match_x": n_match_x, "total": n_total,
            })

    # ── Step 1 汇总 ──
    sep("Step 1 汇总: Token 匹配率")
    print(f"  {'Split':>6s}  {'match_A%':>10s}  {'match_B%':>10s}  {'unique%':>10s}  closer")
    print(f"  {'─' * 55}")
    for split in SPLIT_POINTS:
        entries = [r for r in all_results if r["split"] == split]
        tt = sum(e["total"] for e in entries)
        ta = sum(e["match_a"] for e in entries)
        tb = sum(e["match_b"] for e in entries)
        tx = sum(e["match_x"] for e in entries)
        pa = ta / max(tt, 1)
        pb = tb / max(tt, 1)
        px = tx / max(tt, 1)
        closer = "A" if pa > pb else "B"
        print(f"  {split:>6d}  {pa:>10.1%}  {pb:>10.1%}  {px:>10.1%}  -> {closer}")

    # ================================================================
    #  Step 2: PPL 评估
    # ================================================================
    sep("Step 2: PPL 评估（长文本 Teacher Forcing）")
    for text in PPL_TEXTS:
        short = text[:40] + "..."
        print(f"  '{short}'")

        print(f"    PPL_A...", end="", flush=True)
        r = call_child("pure_ppl", {"model_path": MODEL_PATH_A, "text": text}, work_dir)
        ppl_a = r["ppl"]
        print(f" {ppl_a:.2f}")
        time.sleep(3)

        print(f"    PPL_B...", end="", flush=True)
        r = call_child("pure_ppl", {"model_path": MODEL_PATH_B, "text": text}, work_dir)
        ppl_b = r["ppl"]
        print(f" {ppl_b:.2f}")
        time.sleep(3)

        for split in SPLIT_POINTS:
            print(f"    PPL_R@{split}...", end="", flush=True)
            r = call_child("relay_ppl", {
                "text": text, "split": split, "relay_dir": work_dir,
            }, work_dir)
            ppl_r = r["ppl"]
            best = min(ppl_a, ppl_b)
            ratio_best = ppl_r / best
            ratio_b = ppl_r / ppl_b
            status = "PASS" if ratio_best < 1.5 else ("WARN" if ratio_best < 3.0 else "FAIL")
            print(f" {ppl_r:.2f}  ratio_vs_best={ratio_best:.3f}  ratio_vs_B={ratio_b:.3f}  {status}")
            time.sleep(3)

        print()

    # ── 最终汇总 ──
    sep("Phase 4 Lite 最终汇总")
    total_time = time.time() - t_total
    print(f"""
  总耗时: {total_time:.0f}s ({total_time/60:.1f}min)

  Cancri 截至目前的完整验证链:

  Phase 0   签名探测                PASS
  Phase 1   同模型分层验证          PASS  0.00e+00
  Phase 2   同模型张量接力          PASS  bitwise identical
  Phase 3a  同权重双实例接力        PASS  bitwise identical
  Phase 3a+ 全切分点扫描            PASS  25/25 pass
  Phase 3b  异权重接力(单步)        PASS  PPL ratio 0.95~1.02
  Phase 4   异权重接力(多步)        <- 本次实验

  请把以上完整输出复制发给我
""")


if __name__ == "__main__":
    if "PHASE4_CHILD_STAGE" in os.environ:
        _child_main()
    else:
        main()
