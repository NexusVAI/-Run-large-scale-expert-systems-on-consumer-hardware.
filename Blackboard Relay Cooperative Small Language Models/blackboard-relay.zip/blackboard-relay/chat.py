#!/usr/bin/env python3
"""Cancri-500M chat / inference script.

Loads the released 0.5B checkpoint and chats with it using the exact template the
model was aligned with:

    用户
    {user turn}
    助手
    {assistant turn}<|end_of_text|>

Cancri is board-native: generation runs in 512-token segments and the blackboard
state is written at each segment boundary (see run_cancri.py). Multi-turn history
is kept, so the model sees previous turns.

Usage
-----
Single prompt:
    python chat.py --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json \
        --prompt "你是谁？"

Interactive (multi-turn; type 'exit' / 'quit' to leave, 'reset' to clear history):
    python chat.py --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json -i

Runs on CPU by default; pass --device cuda if you have a GPU.
"""
import argparse
import time

import torch
from tokenizers import Tokenizer

from run_cancri import CancriGPT, generate_board, PAD_ID

EOS_TOKEN = "<|end_of_text|>"


def load_model(ckpt_path, device, dtype):
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    model = CancriGPT(
        vocab=cfg["vocab"], d_model=cfg["d_model"], n_layer=cfg["n_layer"],
        n_head=cfg["n_head"], n_kv_head=cfg["n_kv_head"], inter=cfg["intermediate"],
        rope_theta=cfg["rope_theta"], m=cfg["m"], rms_eps=cfg["rms_eps"],
    )
    model.load_state_dict(ck["model"])
    model = model.to(device)
    if dtype == torch.bfloat16 and device != "cpu":
        model = model.to(dtype)
    model.eval()
    n = sum(p.numel() for p in model.parameters())
    print(f"loaded {ckpt_path} | params={n/1e6:.0f}M | M={cfg['m']} d={cfg['d_model']} "
          f"| {device} {dtype}")
    return model


def build_ids(tok, history, user_msg, eos_id):
    """history = list of (user, assistant); returns token ids for the full prompt."""
    ids = []
    for u, a in history:
        ids += tok.encode(f"用户\n{u}\n助手\n").ids
        ids += tok.encode(a).ids + [eos_id]
    ids += tok.encode(f"用户\n{user_msg}\n助手\n").ids
    return torch.tensor(ids, dtype=torch.long)


def reply(model, tok, history, user_msg, args, eos_id):
    ids = build_ids(tok, history, user_msg, eos_id)
    t0 = time.time()
    out = generate_board(
        model, ids, max_new_tokens=args.max_new_tokens, seg_len=args.seg_len,
        temperature=args.temperature, top_k=args.top_k, top_p=args.top_p,
        repetition_penalty=args.repetition_penalty, pad_id=PAD_ID,
        device=args.device, eos_id=eos_id,
    )
    text = tok.decode(out[len(ids):]).strip()
    return text, len(out) - len(ids), time.time() - t0


def main():
    p = argparse.ArgumentParser(description="Cancri-500M chat")
    p.add_argument("--ckpt", required=True, help="model checkpoint (.ckpt / .pt)")
    p.add_argument("--tokenizer", required=True, help="tokenizer.json (must match training)")
    p.add_argument("--prompt", default="", help="single-turn prompt")
    p.add_argument("-i", "--interactive", action="store_true", help="multi-turn REPL")
    p.add_argument("--device", default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--dtype", default="float32", choices=["float32", "bfloat16"])
    p.add_argument("--max-new-tokens", type=int, default=256)
    p.add_argument("--seg-len", type=int, default=512)
    p.add_argument("--temperature", type=float, default=0.7)
    p.add_argument("--top-k", type=int, default=0)
    p.add_argument("--top-p", type=float, default=0.9)
    p.add_argument("--repetition-penalty", type=float, default=1.15)
    p.add_argument("--threads", type=int, default=4)
    args = p.parse_args()

    torch.set_num_threads(max(1, args.threads))
    if args.device == "cuda" and not torch.cuda.is_available():
        print("CUDA unavailable, falling back to CPU")
        args.device = "cpu"
    dtype = torch.bfloat16 if args.dtype == "bfloat16" else torch.float32

    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id(EOS_TOKEN)
    if eos_id is None:
        raise SystemExit(f"tokenizer has no {EOS_TOKEN}; wrong tokenizer file?")
    model = load_model(args.ckpt, args.device, dtype)

    if args.prompt and not args.interactive:
        text, n, dt = reply(model, tok, [], args.prompt, args, eos_id)
        print(f"\n用户: {args.prompt}\n助手: {text}\n  [{n} tok | {dt:.1f}s]")
        return

    print("Cancri-500M 对话（输入 exit/quit 退出，reset 清空上下文）")
    history = []
    while True:
        try:
            u = input("\n用户: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not u:
            continue
        if u in ("exit", "quit"):
            break
        if u == "reset":
            history = []
            print("[上下文已清空]")
            continue
        text, n, dt = reply(model, tok, history, u, args, eos_id)
        print(f"助手: {text}\n  [{n} tok | {dt:.1f}s]")
        history.append((u, text))


if __name__ == "__main__":
    main()
