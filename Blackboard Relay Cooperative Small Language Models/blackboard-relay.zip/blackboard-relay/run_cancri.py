#!/usr/bin/env python3
"""Cancri 500M PyTorch inference — 直接加载 checkpoint 跑生成（黑板分段路径）。"""
import argparse
import ctypes
import gc
import sys
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
from tokenizers import Tokenizer

# ── Model (copied from cancri_stage1_pretrain.py, inference-only) ──

def rope_cos_sin(seq_len, head_dim, device, theta=500000.0):
    inv_freq = 1.0 / (theta ** (torch.arange(0, head_dim, 2, device=device).float() / head_dim))
    pos = torch.arange(seq_len, device=device).float()
    freqs = torch.outer(pos, inv_freq)
    emb = torch.cat([freqs, freqs], dim=-1)
    return emb.cos(), emb.sin()

def _rotate_half(x):
    x1, x2 = x[..., : x.shape[-1] // 2], x[..., x.shape[-1] // 2:]
    return torch.cat([-x2, x1], dim=-1)

def apply_rope(x, cos, sin):
    return x * cos[None, None] + _rotate_half(x) * sin[None, None]

class RMSNorm(nn.Module):
    def __init__(self, d, eps=1e-6):
        super().__init__()
        self.w = nn.Parameter(torch.ones(d))
        self.eps = eps
    def forward(self, x):
        dt = x.dtype
        x = x.float()
        n = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return (n * self.w.float()).to(dt)

class Attn(nn.Module):
    def __init__(self, d, n_head, n_kv_head):
        super().__init__()
        self.n_head, self.n_kv = n_head, n_kv_head
        self.hd = d // n_head
        self.rep = n_head // n_kv_head
        self.q = nn.Linear(d, n_head * self.hd, bias=False)
        self.k = nn.Linear(d, n_kv_head * self.hd, bias=False)
        self.v = nn.Linear(d, n_kv_head * self.hd, bias=False)
        self.o = nn.Linear(n_head * self.hd, d, bias=False)
    def forward(self, x, cos, sin):
        B, L, _ = x.shape
        q = self.q(x).view(B, L, self.n_head, self.hd).transpose(1, 2)
        k = self.k(x).view(B, L, self.n_kv, self.hd).transpose(1, 2)
        v = self.v(x).view(B, L, self.n_kv, self.hd).transpose(1, 2)
        q, k = apply_rope(q, cos, sin), apply_rope(k, cos, sin)
        if self.rep > 1:
            k = k.repeat_interleave(self.rep, dim=1)
            v = v.repeat_interleave(self.rep, dim=1)
        out = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.o(out.transpose(1, 2).reshape(B, L, self.n_head * self.hd))

class MLP(nn.Module):
    def __init__(self, d, hidden):
        super().__init__()
        self.w1 = nn.Linear(d, hidden, bias=False)
        self.w3 = nn.Linear(d, hidden, bias=False)
        self.w2 = nn.Linear(hidden, d, bias=False)
    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))

class Block(nn.Module):
    def __init__(self, d, n_head, n_kv_head, inter, eps):
        super().__init__()
        self.ln1 = RMSNorm(d, eps)
        self.attn = Attn(d, n_head, n_kv_head)
        self.ln2 = RMSNorm(d, eps)
        self.mlp = MLP(d, inter)
    def forward(self, x, cos, sin):
        x = x + self.attn(self.ln1(x), cos, sin)
        x = x + self.mlp(self.ln2(x))
        return x

class CancriGPT(nn.Module):
    def __init__(self, vocab, d_model, n_layer, n_head, n_kv_head, inter, rope_theta, m, rms_eps):
        super().__init__()
        self.d = d_model
        self.M = m
        self.hd = d_model // n_head
        self.rope_theta = rope_theta
        self.emb = nn.Embedding(vocab, d_model)
        self.board0 = nn.Parameter(torch.randn(m, d_model) * 0.02)
        self.write_q = nn.Parameter(torch.randn(m, d_model) * 0.02)
        self.blocks = nn.ModuleList([
            Block(d_model, n_head, n_kv_head, inter, rms_eps) for _ in range(n_layer)
        ])
        self.norm = RMSNorm(d_model, rms_eps)

    def _backbone(self, seq):
        cos, sin = rope_cos_sin(seq.shape[1], self.hd, seq.device, self.rope_theta)
        h = seq
        for b in self.blocks:
            h = b(h, cos, sin)
        return self.norm(h)

    def _logits(self, h):
        return h @ self.emb.weight.t()

    def forward_plain(self, ids):
        h = self._backbone(self.emb(ids))
        return self._logits(h)

    def forward_segment(self, seg_ids, board_in, with_write=True):
        B, S = seg_ids.shape
        M = self.M
        parts = [board_in, self.emb(seg_ids)]
        if with_write:
            parts.append(self.write_q.unsqueeze(0).expand(B, -1, -1))
        h = self._backbone(torch.cat(parts, dim=1))
        seg_logits = self._logits(h[:, M - 1:M - 1 + S, :])
        board_out = h[:, M + S:M + S + M, :] if with_write else None
        return seg_logits, board_out

    def board0_batch(self, B):
        return self.board0.unsqueeze(0).expand(B, -1, -1)

# ── Generation ──

@torch.no_grad()
def generate_plain(model, input_ids, max_new_tokens, temperature=0.8, top_k=40, top_p=0.9, device='cpu'):
    model.eval()
    ids = input_ids.to(device)
    for _ in range(max_new_tokens):
        logits = model.forward_plain(ids.unsqueeze(0))
        next_logits = logits[0, -1] / temperature
        if top_k > 0:
            v, _ = torch.topk(next_logits, min(top_k, next_logits.shape[-1]))
            next_logits[next_logits < v[-1]] = float('-inf')
        if top_p < 1.0:
            sorted_logits, sorted_idx = torch.sort(next_logits, descending=True)
            cum_probs = torch.softmax(sorted_logits, dim=-1).cumsum(dim=-1)
            remove = cum_probs > top_p
            remove[1:] = remove[:-1].clone()
            remove[0] = False
            sorted_logits[remove] = float('-inf')
            next_logits = sorted_logits.scatter(0, sorted_idx, sorted_logits)
        probs = torch.softmax(next_logits, dim=-1)
        next_id = torch.multinomial(probs, num_samples=1)
        ids = torch.cat([ids, next_id])
    return ids

def _sample_logits(next_logits, temperature, top_k, top_p):
    next_logits = next_logits / temperature
    if top_k > 0:
        v, _ = torch.topk(next_logits, min(top_k, next_logits.shape[-1]))
        next_logits = next_logits.clone()
        next_logits[next_logits < v[-1]] = float("-inf")
    if top_p < 1.0:
        sorted_logits, sorted_idx = torch.sort(next_logits, descending=True)
        cum_probs = torch.softmax(sorted_logits, dim=-1).cumsum(dim=-1)
        remove = cum_probs > top_p
        remove[1:] = remove[:-1].clone()
        remove[0] = False
        sorted_logits = sorted_logits.clone()
        sorted_logits[remove] = float("-inf")
        next_logits = sorted_logits.scatter(0, sorted_idx, sorted_logits)
    probs = torch.softmax(next_logits, dim=-1)
    return torch.multinomial(probs, num_samples=1).item()


@torch.no_grad()
def generate_board(
    model,
    input_ids,
    max_new_tokens,
    seg_len=512,
    temperature=0.7,
    top_k=0,
    top_p=0.85,
    repetition_penalty=1.15,
    pad_id=2,
    device="cpu",
    eos_id=None,
):
    """黑板分段生成：与训练一致，512 token 一段，段末写黑板。生成到 eos_id 即停。"""
    model.eval()
    prompt = input_ids.to(device).tolist()
    board = model.board0_batch(1)
    seg = torch.full((seg_len,), pad_id, dtype=torch.long, device=device)
    seg_pos = 0
    generated = []
    history = []

    def commit_segment():
        nonlocal board, seg, seg_pos
        _, board_out = model.forward_segment(seg.unsqueeze(0), board, with_write=True)
        board = board_out
        seg = torch.full((seg_len,), pad_id, dtype=torch.long, device=device)
        seg_pos = 0

    def ingest_token(tid):
        nonlocal seg_pos
        seg[seg_pos] = tid
        seg_pos += 1
        history.append(tid)
        if seg_pos >= seg_len:
            commit_segment()

    for tid in prompt:
        ingest_token(tid)

    for _ in range(max_new_tokens):
        logits, _ = model.forward_segment(seg.unsqueeze(0), board, with_write=False)
        next_logits = logits[0, seg_pos]

        if repetition_penalty != 1.0:
            next_logits = next_logits.clone()
            for tid in set(history[-256:]):
                if next_logits[tid] > 0:
                    next_logits[tid] /= repetition_penalty
                else:
                    next_logits[tid] *= repetition_penalty

        next_id = _sample_logits(next_logits, temperature, top_k, top_p)
        if eos_id is not None and next_id == eos_id:
            break  # 答完即停，不把 EOS 计入输出
        generated.append(next_id)
        ingest_token(next_id)

    return prompt + generated

DEFAULT_CKPT = "cancri_500m_infer.pt"
DEFAULT_FULL_CKPT = "cancri_500m.ckpt.best"
DEFAULT_TOKENIZER = "tokenizer.json"
# Use the exact 32k BPE tokenizer the model was trained with; a mismatched
# tokenizer (different md5) will produce garbled output.
DEFAULT_PROMPT = "一元二次方程 ax²+bx+c=0 的求根公式是"

# ── 推理默认参数（与训练对齐 + 采样 preset）──
# 训练：seg_len=512, M=32, pad_id=2(<|pad|>), forward_segment, rope_theta=500000
# 采样无训练侧标准值；continue=预训练续写，chat=对话 smoke（模型未 SFT，仅作格式测试）
INFER_PRESETS = {
    "continue": dict(
        temperature=0.85,
        top_k=0,
        top_p=0.92,
        repetition_penalty=1.08,
        max_new_tokens=96,
        seg_len=512,
    ),
    "chat": dict(
        temperature=0.75,
        top_k=0,
        top_p=0.90,
        repetition_penalty=1.10,
        max_new_tokens=24,
        seg_len=512,
    ),
    "greedy": dict(
        temperature=1e-6,
        top_k=1,
        top_p=1.0,
        repetition_penalty=1.0,
        max_new_tokens=64,
        seg_len=512,
    ),
}
DEFAULT_PRESET = "continue"
PAD_ID = 2  # <|pad|>, matches the training tokenizer


def free_ram_gb():
    """Windows 可用物理内存（GB），无额外依赖。"""
    if sys.platform != "win32":
        return None
    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]
    stat = MEMORYSTATUSEX()
    stat.dwLength = ctypes.sizeof(stat)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
        return None
    return stat.ullAvailPhys / (1024 ** 3)


def require_free_ram(min_gb, action):
    free = free_ram_gb()
    if free is None:
        print(f"  [warn] 无法读取可用内存，继续 {action}")
        return
    print(f"  可用内存: {free:.1f} GB（需要 ≥ {min_gb:.0f} GB）")
    if free < min_gb:
        raise SystemExit(
            f"可用内存 {free:.1f} GB 不足 {min_gb:.0f} GB，已中止以免再次蓝屏。"
            "请关闭其它程序后重试，或用 --export-infer 单独导出轻量权重。"
        )


def export_infer_pt(full_path, out_path):
    require_free_ram(6.0, "导出 infer 权重")
    print(f"导出轻量推理包: {full_path} → {out_path}")
    ckpt = torch.load(full_path, map_location="cpu", weights_only=False)
    slim = {"model": ckpt["model"], "step": ckpt["step"], "cfg": ckpt["cfg"]}
    del ckpt
    gc.collect()
    torch.save(slim, out_path)
    mb = __import__("os").path.getsize(out_path) / (1024 ** 2)
    print(f"  完成: {mb:.0f} MB（不含 optimizer，省 ~3GB 内存）")


def parse_args():
    p = argparse.ArgumentParser(description="Cancri 黑板架构本地推理（16GB 机器安全模式）")
    p.add_argument("--ckpt", default=DEFAULT_CKPT, help="推理 checkpoint（默认轻量 infer.pt）")
    p.add_argument("--full-ckpt", default=DEFAULT_FULL_CKPT, help="完整训练 ckpt，供 --export-infer 用")
    p.add_argument("--export-infer", action="store_true", help="从 full-ckpt 导出 infer.pt 后退出")
    p.add_argument("--tokenizer", default=DEFAULT_TOKENIZER, help="tokenizer.json（须与训练一致）")
    p.add_argument("--prompt", default=DEFAULT_PROMPT, help="输入文本")
    p.add_argument("--prompt-file", default="", help="从文件读取 prompt（UTF-8）")
    p.add_argument(
        "--preset",
        choices=list(INFER_PRESETS.keys()),
        default=DEFAULT_PRESET,
        help="采样 preset：continue=中文/英文续写，chat=对话 smoke，greedy=近似贪心",
    )
    p.add_argument("--max-new-tokens", type=int, default=None, help="覆盖 preset 的生成长度")
    p.add_argument("--threads", type=int, default=4, help="PyTorch CPU 线程数，避免占满 i5-10400")
    p.add_argument("--seg-len", type=int, default=None, help="训练段长，默认 512（与 checkpoint 一致）")
    p.add_argument("--temperature", type=float, default=None)
    p.add_argument("--top-k", type=int, default=None, help="0=禁用 top-k")
    p.add_argument("--top-p", type=float, default=None)
    p.add_argument("--repetition-penalty", type=float, default=None)
    p.add_argument("--device", default="cpu", choices=["cpu", "cuda"])
    p.add_argument("--interactive", action="store_true", help="交互式多轮对话")
    args = p.parse_args()
    preset = INFER_PRESETS[args.preset]
    if args.max_new_tokens is None:
        args.max_new_tokens = preset["max_new_tokens"]
    if args.seg_len is None:
        args.seg_len = preset["seg_len"]
    if args.temperature is None:
        args.temperature = preset["temperature"]
    if args.top_k is None:
        args.top_k = preset["top_k"]
    if args.top_p is None:
        args.top_p = preset["top_p"]
    if args.repetition_penalty is None:
        args.repetition_penalty = preset["repetition_penalty"]
    return args


def load_model(ckpt_path, device):
    require_free_ram(4.0, "加载模型")
    print("Loading checkpoint...")
    ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ckpt["cfg"]
    print(f"  cfg: {cfg}")
    print(f"  step: {ckpt['step']}")

    print("Building model...")
    model = CancriGPT(
        vocab=cfg["vocab"],
        d_model=cfg["d_model"],
        n_layer=cfg["n_layer"],
        n_head=cfg["n_head"],
        n_kv_head=cfg["n_kv_head"],
        inter=cfg["intermediate"],
        rope_theta=cfg["rope_theta"],
        m=cfg["m"],
        rms_eps=cfg["rms_eps"],
    )
    model.load_state_dict(ckpt["model"])
    model = model.to(device)
    model.eval()
    n_params = sum(p.numel() for p in model.parameters())
    print(f"  params: {n_params/1e6:.1f}M")
    return model, ckpt


def run_once(model, tok, prompt, args):
    ids = torch.tensor(tok.encode(prompt).ids, dtype=torch.long)
    print(f"\n{'='*60}")
    print(f"Prompt ({len(ids)} tokens)")
    print(f"{'='*60}")
    print(prompt[:200] + ("..." if len(prompt) > 200 else ""))

    t0 = time.time()
    eos_id = tok.token_to_id("<|end_of_text|>")
    out_ids = generate_board(
        model,
        ids,
        max_new_tokens=args.max_new_tokens,
        seg_len=args.seg_len,
        temperature=args.temperature,
        top_k=args.top_k,
        top_p=args.top_p,
        repetition_penalty=args.repetition_penalty,
        pad_id=PAD_ID,
        device=args.device,
        eos_id=eos_id,
    )
    elapsed = time.time() - t0
    gen_text = tok.decode(out_ids[len(ids):])
    n_gen = len(out_ids) - len(ids)
    print(f"\n[board preset={args.preset}] continuation ({n_gen} tok):\n{gen_text}")
    print(
        f"  [{elapsed:.1f}s | temp={args.temperature} top_p={args.top_p} "
        f"top_k={args.top_k} rep={args.repetition_penalty} seg={args.seg_len}]"
    )
    return gen_text


def main():
    args = parse_args()
    torch.set_num_threads(max(1, args.threads))

    if args.export_infer:
        export_infer_pt(args.full_ckpt, args.ckpt)
        return

    if args.prompt_file:
        with open(args.prompt_file, encoding="utf-8") as f:
            args.prompt = f.read()

    if args.device == "cuda" and not torch.cuda.is_available():
        print("CUDA 不可用，回退到 CPU")
        args.device = "cpu"

    import os
    if not os.path.isfile(args.ckpt):
        print(f"未找到 {args.ckpt}，先从完整 ckpt 导出轻量包…")
        export_infer_pt(args.full_ckpt, args.ckpt)

    model, ck = load_model(args.ckpt, args.device)
    print("Loading tokenizer...")
    tok = Tokenizer.from_file(args.tokenizer)
    print(
        f"  preset={args.preset} | step={ck['step']} | "
        f"temp={args.temperature} top_p={args.top_p} top_k={args.top_k} "
        f"rep={args.repetition_penalty} max_new={args.max_new_tokens} seg={args.seg_len}"
    )

    if args.interactive:
        print("\n交互模式（黑板分段生成）。空行退出。")
        while True:
            try:
                prompt = input("\n>>> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not prompt:
                break
            run_once(model, tok, prompt, args)
        return

    run_once(model, tok, args.prompt, args)


if __name__ == "__main__":
    main()
