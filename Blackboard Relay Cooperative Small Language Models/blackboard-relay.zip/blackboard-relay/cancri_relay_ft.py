#!/usr/bin/env python3
"""Cancri Stage 2 —— relay 微调（机制 a：物理旁路阻断）。

目标：把 dpo6 从"板是高保真信道、但零样本不会从板正确生成"训成"能只凭 latent 板生成正确答案"。

机制 a（物理旁路阻断，文档 §7 选定）：
  上游段 = 「用户\\n{q}\\n」 → forward_segment(board0, with_write=True) → board_Q
  下游段 = 「助手\\n{a}<eos>」，board_in=board_Q，**下游段绝不含问题文字**。
  ⇒ 跨段信息唯一通路 = board_Q。模型想降低答案 CE，只能学会「读板」。旁路（把问题当文本看）
     被结构性禁止，因此无需论文里的 no-board anchor —— 依赖是硬性的。
  上游/下游当前共享同一份权重（先把 relay 能力训进基座）；分叉成 knowledge/reasoning/… 专家留后续。

loss = CE(answer | board_Q)  （teacher forcing，只在答案 token 上计分，助手前缀 mask 掉）
可选 --board-dropout：以一定概率把 board_Q 换成 board0，训练"没拿到上游信息时别乱编"的鲁棒性
  （默认 0：Stage 2 要的就是全依赖）。

数据（任一格式，每行一条 jsonl，可 .gz）：
  {"messages":[{"role":"user",...},{"role":"assistant",...}]}   # 取最后一组 user/assistant
  {"question":"...", "answer":"..."}
  {"chosen":[{"role":"user"...},{"role":"assistant"...}]}       # 复用 dpo 的 chosen

用法（MI300X，bf16）：
  python -u -X utf8 cancri_relay_ft.py --mode run --device cuda --dtype bfloat16 \
    --base cancri_500m_dpo6.ckpt --tokenizer tokenizer.json --data sft_clean2.jsonl \
    --out cancri_500m_relay1.ckpt --epochs 2 --batch-size 8 --lr 1e-5 \
    --eval-every 200 --out-csv relay1_log.csv
  python -X utf8 cancri_relay_ft.py --mode smoke
"""
from __future__ import annotations

import argparse
import csv
import gzip
import json
import math
import random
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from tokenizers import Tokenizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_cancri import CancriGPT  # noqa: E402

PAD_ID = 2
IGN = -100


# ── 数据 ──
def _extract_qa(obj):
    """从多种格式里抽出 (question, answer)。取不到返回 None。"""
    if "question" in obj and "answer" in obj:
        return str(obj["question"]).strip(), str(obj["answer"]).strip()
    msgs = obj.get("messages") or obj.get("chosen")
    if isinstance(msgs, list):
        q = a = None
        for m in msgs:
            r, c = m.get("role", ""), (m.get("content") or "").strip()
            if not c:
                continue
            if r == "user":
                q = c
            elif r == "assistant":
                a = c
        if q and a:
            return q, a
    return None


def load_qa(path, tok, eos_id, max_q, max_a, lang, max_samples):
    opener = gzip.open if str(path).endswith(".gz") else open
    out, skip, seen = [], 0, 0
    print(f"  读取 {path} …（大文件会先整份分词，耐心等；可用 --max-samples 限量）", flush=True)
    with opener(path, "rt", encoding="utf-8") as f:
        for line in f:
            seen += 1
            if seen % 20000 == 0:
                print(f"    …已扫描 {seen} 行，收得 {len(out)} 条", flush=True)
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if lang and obj.get("lang") not in (None, lang):
                continue
            qa = _extract_qa(obj)
            if not qa:
                continue
            q, a = qa
            q_ids = tok.encode(f"用户\n{q}\n").ids                 # 上游读题段
            head = tok.encode("助手\n").ids                        # 下游可见前缀（mask）
            a_ids = tok.encode(a).ids + [eos_id]                   # 答案 token（计分）
            if len(q_ids) > max_q or len(head) + len(a_ids) > max_a:
                skip += 1
                continue
            down_ids = head + a_ids
            down_lab = [IGN] * len(head) + a_ids                   # 只在答案+eos 上计分
            out.append((q_ids, down_ids, down_lab))
            if max_samples and len(out) >= max_samples:
                break
    print(f"  有效 QA {len(out)}，超长跳过 {skip}")
    return out


def pad(seqs, fill, device):
    S = max(len(s) for s in seqs)
    t = torch.full((len(seqs), S), fill, dtype=torch.long)
    for i, s in enumerate(seqs):
        t[i, :len(s)] = torch.tensor(s, dtype=torch.long)
    return t.to(device)


# ── relay 前向 + loss ──
def relay_answer_logits(model, q_ids, down_ids, board_dropout=0.0):
    """上游读题写 board_Q → 下游在 board_Q 下算答案段 logits。返回 [B,S_down,V]。"""
    B = q_ids.size(0)
    board0 = model.board0_batch(B)
    _, board_q = model.forward_segment(q_ids, board0, with_write=True)   # 上游写板
    if board_dropout > 0:
        mask = (torch.rand(B, 1, 1, device=q_ids.device) < board_dropout).float()
        board_q = mask * model.board0_batch(B) + (1.0 - mask) * board_q
    logits, _ = model.forward_segment(down_ids, board_q, with_write=False)  # 下游读板
    return logits


def relay_loss(model, q_ids, down_ids, down_lab, board_dropout=0.0):
    logits = relay_answer_logits(model, q_ids, down_ids, board_dropout)     # [B,S,V]
    logp = F.log_softmax(logits.float(), dim=-1)
    tok_logp = logp.gather(-1, down_ids.unsqueeze(-1)).squeeze(-1)          # 黑板路径无 shift
    mask = (down_lab != IGN).float()
    nll = -(tok_logp * mask).sum() / mask.sum().clamp(min=1.0)
    return nll


@torch.no_grad()
def eval_board_lift(model, samples, device, n=64):
    """held-out：答案在 board_Q（real）vs board0（null）下的 CE → board_lift = ppl_null - ppl_real。"""
    model.eval()
    # 权重可能是 bf16，而 RoPE 的 cos/sin 是 fp32 → SDPA 前 q/k 会被提升成 fp32、v 仍 bf16 → dtype 不一致。
    # 训练走 autocast 无碍；eval 不在 autocast 里，这里显式包一层与权重一致的 autocast。
    p_dtype = next(model.parameters()).dtype
    ac = torch.autocast(device.type, dtype=p_dtype, enabled=(p_dtype == torch.bfloat16))
    ce_real, ce_null = [], []
    with ac:
      for q_ids, down_ids, down_lab in samples[:n]:
        q = torch.tensor(q_ids, dtype=torch.long, device=device).unsqueeze(0)
        d = torch.tensor(down_ids, dtype=torch.long, device=device).unsqueeze(0)
        lab = torch.tensor(down_lab, dtype=torch.long, device=device).unsqueeze(0)
        l_real = relay_answer_logits(model, q, d, 0.0)[0].float()
        board0 = model.board0_batch(1)
        l_null, _ = model.forward_segment(d, board0, with_write=False)
        l_null = l_null[0].float()
        m = (lab[0] != IGN)
        tgt = d[0][m]
        ce_real.append(F.cross_entropy(l_real[m], tgt).item())
        ce_null.append(F.cross_entropy(l_null[m], tgt).item())
    mean = lambda xs: sum(xs) / len(xs)
    ppl_real, ppl_null = math.exp(mean(ce_real)), math.exp(mean(ce_null))
    model.train()
    return dict(ppl_real=ppl_real, ppl_null=ppl_null, board_lift=ppl_null - ppl_real)


def build_model(ckpt_path, device):
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    model = CancriGPT(
        vocab=cfg["vocab"], d_model=cfg["d_model"], n_layer=cfg["n_layer"],
        n_head=cfg["n_head"], n_kv_head=cfg["n_kv_head"], inter=cfg["intermediate"],
        rope_theta=cfg["rope_theta"], m=cfg["m"], rms_eps=cfg["rms_eps"],
    )
    model.load_state_dict(ck["model"])
    return model.to(device), cfg, ck.get("step", 0)


def cosine_lr(step, total, base, warmup, min_ratio=0.1):
    if step < warmup:
        return base * step / max(1, warmup)
    p = (step - warmup) / max(1, total - warmup)
    return base * (min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * p)))


def run_smoke():
    torch.manual_seed(0)
    device = torch.device("cpu")
    model = CancriGPT(vocab=300, d_model=64, n_layer=2, n_head=4, n_kv_head=2,
                      inter=128, rope_theta=500000.0, m=8, rms_eps=1e-6).to(device)
    # 造几条假 QA（走真实 pad/loss 路径）
    samples = []
    for k in range(6):
        q = [5 + (k * 3 + i) % 200 for i in range(12)]
        head = [7, 8]
        a = [10 + (k + i) % 200 for i in range(10)] + [3]
        samples.append((q, head + a, [IGN] * len(head) + a))
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    model.train()
    l0 = None
    for step in range(1, 31):
        b = samples[:4]
        q = pad([x[0] for x in b], PAD_ID, device)
        d = pad([x[1] for x in b], PAD_ID, device)
        lab = pad([x[2] for x in b], IGN, device)
        loss = relay_loss(model, q, d, lab, board_dropout=0.1)
        opt.zero_grad(); loss.backward(); opt.step()
        if step == 1:
            l0 = loss.item()
    lift = eval_board_lift(model, samples, device)
    assert loss.item() < l0 + 1.0  # 能反传、loss 有动
    assert set(lift) == {"ppl_real", "ppl_null", "board_lift"}
    print(f"[smoke] relay-ft OK：loss {l0:.3f}→{loss.item():.3f} | "
          f"board_lift {lift['board_lift']:+.3f} (随机模型仅验管线)")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", default="run", choices=["run", "smoke"])
    p.add_argument("--base")
    p.add_argument("--tokenizer")
    p.add_argument("--data")
    p.add_argument("--out", default="cancri_500m_relay1.ckpt")
    p.add_argument("--out-csv", default="relay_ft_log.csv")
    p.add_argument("--device", default="cuda", choices=["cpu", "cuda"])
    p.add_argument("--dtype", default="bfloat16", choices=["float32", "bfloat16"])
    p.add_argument("--epochs", type=float, default=2.0)
    p.add_argument("--steps", type=int, default=0)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--grad-accum", type=int, default=1)
    p.add_argument("--max-q", type=int, default=512)
    p.add_argument("--max-a", type=int, default=512)
    p.add_argument("--lr", type=float, default=1e-5)
    p.add_argument("--warmup-ratio", type=float, default=0.03)
    p.add_argument("--board-dropout", type=float, default=0.0)
    p.add_argument("--eval-every", type=int, default=200)
    p.add_argument("--save-every", type=int, default=1000)
    p.add_argument("--eval-n", type=int, default=64)
    p.add_argument("--lang", default="")
    p.add_argument("--max-samples", type=int, default=0)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    if args.mode == "smoke":
        run_smoke()
        return

    if not (args.base and args.tokenizer and args.data):
        raise SystemExit("--mode run 需要 --base --tokenizer --data")

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(args.device if (args.device == "cpu" or torch.cuda.is_available()) else "cpu")
    dtype = torch.bfloat16 if (args.dtype == "bfloat16" and device.type == "cuda") else torch.float32

    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id("<|end_of_text|>")
    if eos_id is None:
        raise SystemExit("tokenizer 里找不到 <|end_of_text|>")

    data = load_qa(args.data, tok, eos_id, args.max_q, args.max_a, args.lang, args.max_samples)
    if len(data) < args.batch_size + args.eval_n:
        raise SystemExit(f"样本太少：{len(data)}")
    random.shuffle(data)
    eval_set = data[:args.eval_n]
    train = data[args.eval_n:]

    model, cfg, base_step = build_model(args.base, device)
    if dtype == torch.bfloat16:
        model = model.to(dtype=torch.bfloat16)
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.0, betas=(0.9, 0.95))

    steps_per_epoch = math.ceil(len(train) / (args.batch_size * args.grad_accum))
    total = args.steps if args.steps > 0 else int(steps_per_epoch * args.epochs)
    warmup = max(1, int(total * args.warmup_ratio))
    print(f"train {len(train)} | eval {len(eval_set)} | steps/epoch={steps_per_epoch} | "
          f"total={total} | warmup={warmup} | bpdrop={args.board_dropout} | eff_batch={args.batch_size*args.grad_accum}")

    lift0 = eval_board_lift(model, eval_set, device, args.eval_n)
    print(f"  [init] board_lift={lift0['board_lift']:+.3f}  ppl_real={lift0['ppl_real']:.2f}  ppl_null={lift0['ppl_null']:.2f}")

    csv_f = open(args.out_csv, "w", newline="", encoding="utf-8")
    cw = csv.writer(csv_f)
    cw.writerow(["step", "loss", "lr", "board_lift", "ppl_real", "ppl_null", "tok_s"])

    order = list(range(len(train)))
    ptr = 0

    def next_batch():
        nonlocal ptr
        if ptr + args.batch_size > len(order):
            random.shuffle(order)
            ptr = 0
        idx = order[ptr:ptr + args.batch_size]
        ptr += args.batch_size
        return [train[i] for i in idx]

    t0 = time.time()
    best = -1e9
    for step in range(1, total + 1):
        lr = cosine_lr(step, total, args.lr, warmup)
        for g in opt.param_groups:
            g["lr"] = lr
        opt.zero_grad(set_to_none=True)
        agg = 0.0
        ntok = 0
        for _ in range(args.grad_accum):
            b = next_batch()
            q = pad([x[0] for x in b], PAD_ID, device)
            d = pad([x[1] for x in b], PAD_ID, device)
            lab = pad([x[2] for x in b], IGN, device)
            ntok += int((lab != IGN).sum().item())
            with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
                loss = relay_loss(model, q, d, lab, args.board_dropout) / args.grad_accum
            loss.backward()
            agg += loss.item()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        if step % args.eval_every == 0 or step == total or step == 1:
            lift = eval_board_lift(model, eval_set, device, args.eval_n)
            tok_s = ntok * step / max(1e-6, time.time() - t0)
            print(f"  step {step}/{total}  loss={agg:.4f}  lr={lr:.2e}  "
                  f"board_lift={lift['board_lift']:+.3f}  ppl_real={lift['ppl_real']:.2f}  "
                  f"ppl_null={lift['ppl_null']:.2f}  {time.time()-t0:.0f}s", flush=True)
            cw.writerow([step, f"{agg:.4f}", f"{lr:.2e}", f"{lift['board_lift']:.4f}",
                         f"{lift['ppl_real']:.4f}", f"{lift['ppl_null']:.4f}", f"{tok_s:.0f}"])
            csv_f.flush()
            if lift["board_lift"] > best:
                best = lift["board_lift"]
                torch.save({"model": {k: v.cpu() for k, v in model.state_dict().items()},
                            "step": base_step, "cfg": cfg}, args.out + ".best")
        if args.save_every and step % args.save_every == 0:
            torch.save({"model": {k: v.cpu() for k, v in model.state_dict().items()},
                        "step": base_step, "cfg": cfg}, args.out)

    torch.save({"model": {k: v.cpu() for k, v in model.state_dict().items()},
                "step": base_step, "relay_steps": total, "cfg": cfg}, args.out)
    csv_f.close()
    print(f"完成 {time.time()-t0:.0f}s → {args.out}（best board_lift={best:+.3f} 存于 {args.out}.best）")


if __name__ == "__main__":
    main()
