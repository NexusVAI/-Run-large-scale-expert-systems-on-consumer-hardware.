#!/usr/bin/env python3
"""Cancri 上下文-relay harness —— A(板=附加状态) + C(多线索综合，量化板增益)。

和 cancri_relay.py 的区别（也是从 relay1 诊断学到的教训）：
  - relay.py = 纯隐(机制a 物理旁路阻断)：下游只凭板，问题原文不可见 → 精确数值有损。
  - relay2.py = **板 = 附加状态**（放开旁路）：
        上游专家读【上下文/线索】→ 压成 board_ctx
        下游专家【同时看到问题原文(精确) + board_ctx(压缩的上下文要点)】→ 作答
    板携带的是"文本里没有的东西"(长上下文/多线索的压缩)，问题本身仍走精确文本。
    这才是 BRP 的现实推理形态：文本管精确，板管跨专家的要点/状态。

诊断（对齐论文的 context→board→continuation 框架）：
  ppl_none  : 答案 | (问题文本, 空板)                 —— 只有问题、没上下文（下界）
  ppl_board : 答案 | (问题文本, board(上下文))         —— A/C：上下文压成板 + 问题文本
  ppl_full  : 答案 | (上下文文本+问题文本, 空板)        —— 上下文全以文字给（上界）
  board_lift = ppl_none - ppl_board       >0 ⇒ 压缩的上下文板确实帮到了作答
  recovery   = (ppl_none-ppl_board)/(ppl_none-ppl_full)   ~1 ⇒ 板≈补回全部上下文价值

用法：
  # 先造一份多线索综合合成集（关系/属性 join，弱算术，适配 0.5B）
  python -X utf8 cancri_relay2.py --mode synth --out relay2_synth.jsonl --n 300
  # 定量：板到底帮了多少
  python -u -X utf8 cancri_relay2.py --mode board-lift --device cuda --dtype bfloat16 \
    --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json --data relay2_synth.jsonl
  # 定性：板+文本 vs 只有问题 vs 全文本
  python -u -X utf8 cancri_relay2.py --mode gen --device cuda --dtype bfloat16 \
    --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json --data relay2_synth.jsonl
  python -X utf8 cancri_relay2.py --mode smoke
"""
from __future__ import annotations

import argparse
import gzip
import json
import math
import random
import sys
from pathlib import Path

import torch
import torch.nn.functional as F
from tokenizers import Tokenizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_cancri import CancriGPT, _sample_logits  # noqa: E402

PAD_ID = 2
IGN = -100


# ── C：多线索综合合成数据（关系/属性 join，避开重算术，适配 0.5B）──
_NAMES = ["小明", "小红", "小刚", "阿伟", "丽丽", "老王", "阿强", "婷婷", "大壮", "小美"]
_COLORS = ["红色", "蓝色", "绿色", "黄色", "紫色", "橙色", "黑色", "白色"]
_PETS = ["猫", "狗", "兔子", "乌龟", "鹦鹉", "仓鼠", "金鱼", "蜥蜴"]
_CITIES = ["北京", "上海", "广州", "成都", "杭州", "西安", "武汉", "南京"]


def _gen_attr_lookup(rng):
    """属性反查：给若干人各自的属性，问"具备某属性的是谁"（需读全上下文）。"""
    people = rng.sample(_NAMES, 4)
    colors = rng.sample(_COLORS, 4)
    facts = [f"{p}喜欢{c}。" for p, c in zip(people, colors)]
    rng.shuffle(facts)
    i = rng.randrange(4)
    ctx = "".join(facts)
    q = f"谁喜欢{colors[i]}？"
    a = f"{people[i]}喜欢{colors[i]}。"
    return ctx, q, a, people[i]


def _gen_two_hop(rng):
    """两跳组合：A 养了某宠物，宠物所在城市…问 A 的宠物在哪个城市（需串两条线索）。"""
    p = rng.choice(_NAMES)
    pet = rng.choice(_PETS)
    city = rng.choice(_CITIES)
    facts = [f"{p}养了一只{pet}。", f"这只{pet}住在{city}。"]
    # 混入干扰（避开目标人/目标宠物，防"这只{pet}"指代歧义）
    others = [x for x in _NAMES if x != p]
    other_pets = [x for x in _PETS if x != pet]
    for _ in range(2):
        facts.append(f"{rng.choice(others)}养了一只{rng.choice(other_pets)}。")
    rng.shuffle(facts)
    ctx = "".join(facts)
    q = f"{p}的{pet}住在哪个城市？"
    a = f"{p}的{pet}住在{city}。"
    return ctx, q, a, city


def gen_synth(n, seed=0):
    rng = random.Random(seed)
    out = []
    for _ in range(n):
        ctx, q, a, key = (_gen_attr_lookup if rng.random() < 0.5 else _gen_two_hop)(rng)
        out.append({"context": ctx, "question": q, "answer": a, "key": key})
    return out


# ── 编码 / 前向 ──
def to_seg(ids, device):
    return torch.tensor(ids, dtype=torch.long, device=device).unsqueeze(0)


@torch.no_grad()
def board_of_context(model, ctx_ids, device):
    """上游读上下文 → board_ctx [1,M,d]。"""
    board0 = model.board0_batch(1)
    _, board_ctx = model.forward_segment(to_seg(ctx_ids, device), board0, with_write=True)
    return board_ctx


@torch.no_grad()
def answer_ce_given(model, board_in, seg_ids, ans_span, device):
    """seg 在 board_in 下的 CE，只在 ans_span=(start,end) 的答案 token 上计分。"""
    seg = to_seg(seg_ids, device)
    logits, _ = model.forward_segment(seg, board_in, with_write=False)
    logits = logits[0].float()
    tgt = seg[0]
    s, e = ans_span
    return F.cross_entropy(logits[s:e], tgt[s:e]).item()


def _encode_qa(tok, q, a, eos_id):
    head = tok.encode(f"用户\n{q}\n助手\n").ids
    ans = tok.encode(a).ids + [eos_id]
    return head + ans, (len(head), len(head) + len(ans))


def _encode_full(tok, ctx, q, a, eos_id):
    head = tok.encode(f"{ctx}\n用户\n{q}\n助手\n").ids
    ans = tok.encode(a).ids + [eos_id]
    return head + ans, (len(head), len(head) + len(ans))


@torch.no_grad()
def greedy_key(model, board_in, prefix_ids, max_new, eos_id, device, seg_len=512):
    board = model.board0_batch(1) if board_in is None else board_in
    seg = torch.full((seg_len,), PAD_ID, dtype=torch.long, device=device)
    pos = 0
    gen = []
    for tid in prefix_ids:
        seg[pos] = tid
        pos += 1
    for _ in range(max_new):
        logits, _ = model.forward_segment(seg.unsqueeze(0), board, with_write=False)
        nid = int(logits[0, pos].argmax().item())
        if eos_id is not None and nid == eos_id:
            break
        gen.append(nid)
        seg[pos] = nid
        pos += 1
        if pos >= seg_len:
            break
    return gen


def acc_ctx(model, tok, samples, device, eos_id):
    """贪心 exact-key 准确率的三对照：board(板+问题) / null(空板+问题) / full(全文本+问题)。
    board≫null ⇒ 答案真来自板；board≈null ⇒ 只是先验/回声在猜。"""
    hb = hn = hf = tot = 0
    for s in samples:
        key = s.get("key", "")
        if not key:
            continue
        board_ctx = board_of_context(model, tok.encode(s["context"]).ids, device)
        qa_prefix = tok.encode(f"用户\n{s['question']}\n助手\n").ids
        full_prefix = tok.encode(f"{s['context']}\n用户\n{s['question']}\n助手\n").ids
        gb = tok.decode(greedy_key(model, board_ctx, qa_prefix, 24, eos_id, device))
        gn = tok.decode(greedy_key(model, None, qa_prefix, 24, eos_id, device))
        gf = tok.decode(greedy_key(model, None, full_prefix, 24, eos_id, device))
        hb += key in gb
        hn += key in gn
        hf += key in gf
        tot += 1
    tot = max(1, tot)
    return dict(acc_board=hb / tot, acc_null=hn / tot, acc_full=hf / tot, n=tot)


def board_lift_ctx(model, tok, samples, device, eos_id):
    ce_none, ce_board, ce_full = [], [], []
    for s in samples:
        ctx, q, a = s["context"], s["question"], s["answer"]
        board_ctx = board_of_context(model, tok.encode(ctx).ids, device)
        board0 = model.board0_batch(1)
        qa_ids, span = _encode_qa(tok, q, a, eos_id)
        full_ids, fspan = _encode_full(tok, ctx, q, a, eos_id)
        ce_none.append(answer_ce_given(model, board0, qa_ids, span, device))
        ce_board.append(answer_ce_given(model, board_ctx, qa_ids, span, device))
        ce_full.append(answer_ce_given(model, board0, full_ids, fspan, device))
    mean = lambda xs: sum(xs) / len(xs)
    ppl_none, ppl_board, ppl_full = map(lambda xs: math.exp(mean(xs)), (ce_none, ce_board, ce_full))
    lift = ppl_none - ppl_board
    denom = ppl_none - ppl_full
    rec = lift / denom if abs(denom) > 1e-6 else float("nan")
    return dict(ppl_none=ppl_none, ppl_board=ppl_board, ppl_full=ppl_full,
                board_lift=lift, recovery=rec)


@torch.no_grad()
def generate_given(model, board_in, prompt_ids, max_new_tokens, seg_len, eos_id, device,
                   temperature=0.7, top_p=0.9, rep=1.15):
    board = model.board0_batch(1) if board_in is None else board_in
    seg = torch.full((seg_len,), PAD_ID, dtype=torch.long, device=device)
    seg_pos = 0
    history, generated = [], []

    def commit():
        nonlocal board, seg, seg_pos
        _, board = model.forward_segment(seg.unsqueeze(0), board, with_write=True)
        seg = torch.full((seg_len,), PAD_ID, dtype=torch.long, device=device)
        seg_pos = 0

    def ingest(tid):
        nonlocal seg_pos
        seg[seg_pos] = tid
        seg_pos += 1
        history.append(tid)
        if seg_pos >= seg_len:
            commit()

    for tid in prompt_ids:
        ingest(tid)
    for _ in range(max_new_tokens):
        logits, _ = model.forward_segment(seg.unsqueeze(0), board, with_write=False)
        nl = logits[0, seg_pos].clone()
        if rep != 1.0:
            for tid in set(history[-256:]):
                nl[tid] = nl[tid] / rep if nl[tid] > 0 else nl[tid] * rep
        nid = _sample_logits(nl, temperature, 0, top_p)
        if eos_id is not None and nid == eos_id:
            break
        generated.append(nid)
        ingest(nid)
    return generated


def build_model(ckpt_path, device):
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    model = CancriGPT(
        vocab=cfg["vocab"], d_model=cfg["d_model"], n_layer=cfg["n_layer"],
        n_head=cfg["n_head"], n_kv_head=cfg["n_kv_head"], inter=cfg["intermediate"],
        rope_theta=cfg["rope_theta"], m=cfg["m"], rms_eps=cfg["rms_eps"],
    )
    model.load_state_dict(ck["model"])
    return model.to(device).eval(), cfg


def load_data(path):
    out = []
    op = gzip.open if str(path).endswith(".gz") else open
    with op(path, "rt", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            o = json.loads(line)
            if o.get("context") and o.get("question") and o.get("answer"):
                out.append(o)
    return out


def run_smoke():
    torch.manual_seed(0)
    device = torch.device("cpu")
    model = CancriGPT(vocab=300, d_model=64, n_layer=2, n_head=4, n_kv_head=2,
                      inter=128, rope_theta=500000.0, m=8, rms_eps=1e-6).to(device).eval()

    class FakeTok:
        def encode(self, t):
            class E: ...
            e = E(); e.ids = [(ord(c) % 290) + 5 for c in t][:60] or [5]
            return e
        def decode(self, ids): return "".join(chr(65 + (i % 26)) for i in ids)
        def token_to_id(self, t): return 3
    tok = FakeTok()
    samples = gen_synth(8, seed=1)
    agg = board_lift_ctx(model, tok, samples, device, 3)
    assert set(agg) >= {"ppl_none", "ppl_board", "ppl_full", "board_lift", "recovery"}
    b = board_of_context(model, tok.encode(samples[0]["context"]).ids, device)
    g = generate_given(model, b, tok.encode("用户\n问\n助手\n").ids, 6, 64, 3, device)
    assert isinstance(g, list)
    print("[smoke] 上下文-relay OK | 合成样本:", samples[0])
    print("[smoke] board_lift", round(agg["board_lift"], 3), "recovery", round(agg["recovery"], 3))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", default="board-lift", choices=["board-lift", "gen", "acc", "synth", "smoke"])
    p.add_argument("--gen-seed", type=int, default=12345, help="acc/board-lift 无 --data 时现造集的种子（换种子=测泛化）")
    p.add_argument("--ckpt")
    p.add_argument("--tokenizer")
    p.add_argument("--data", default="")
    p.add_argument("--out", default="relay2_synth.jsonl")
    p.add_argument("--n", type=int, default=300)
    p.add_argument("--device", default="cuda", choices=["cpu", "cuda"])
    p.add_argument("--dtype", default="bfloat16", choices=["float32", "bfloat16"])
    p.add_argument("--seg-len", type=int, default=512)
    p.add_argument("--max-new-tokens", type=int, default=64)
    p.add_argument("--limit", type=int, default=100, help="board-lift/gen 评测样本上限")
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    if args.mode == "smoke":
        run_smoke()
        return

    if args.mode == "synth":
        data = gen_synth(args.n, args.seed)
        with open(args.out, "w", encoding="utf-8") as f:
            for o in data:
                f.write(json.dumps(o, ensure_ascii=False) + "\n")
        print(f"生成 {len(data)} 条 → {args.out}")
        for o in data[:4]:
            print("  ", o)
        return

    if not (args.ckpt and args.tokenizer):
        raise SystemExit("--mode board-lift/gen/acc 需要 --ckpt --tokenizer（--data 可选，留空则现造合成集）")

    device = torch.device(args.device if (args.device == "cpu" or torch.cuda.is_available()) else "cpu")
    dtype = torch.bfloat16 if (args.dtype == "bfloat16" and device.type == "cuda") else torch.float32
    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id("<|end_of_text|>")
    model, cfg = build_model(args.ckpt, device)
    if dtype == torch.bfloat16:
        model = model.to(dtype=torch.bfloat16)
    samples = (load_data(args.data) if args.data else gen_synth(args.limit, seed=args.gen_seed))[:args.limit]
    print(f"已加载 {args.ckpt} | M={cfg['m']} d={cfg['d_model']} | {device} {dtype} | 样本 {len(samples)}")

    if args.mode == "board-lift":
        with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
            agg = board_lift_ctx(model, tok, samples, device, eos_id)
        print("\n=== 上下文-relay board_lift（板=附加状态；问题文本始终可见）===")
        print(f"  ppl_none  (只问题,无上下文)   : {agg['ppl_none']:.3f}")
        print(f"  ppl_board (上下文压成板+问题) : {agg['ppl_board']:.3f}")
        print(f"  ppl_full  (上下文全文本+问题) : {agg['ppl_full']:.3f}")
        print(f"  board_lift = none-board       : {agg['board_lift']:+.3f}   (>0 ⇒ 压缩上下文板帮到作答)")
        print(f"  recovery                      : {agg['recovery']:.3f}   (~1 ⇒ 板≈补回全部上下文价值)")
        return

    if args.mode == "acc":
        with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
            agg = acc_ctx(model, tok, samples, device, eos_id)
        print("\n=== 贪心 exact-key 准确率（n=%d，gen-seed=%d 现造集=测泛化）===" % (agg["n"], args.gen_seed))
        print(f"  acc_board (板+问题)  : {agg['acc_board']:.3f}   ← 答案是否真从板解码")
        print(f"  acc_null  (空板+问题): {agg['acc_null']:.3f}   ← 无上下文时的先验/回声基线")
        print(f"  acc_full  (全文本+问题): {agg['acc_full']:.3f} ← 上界")
        print(f"  板贡献 = board-null   : {agg['acc_board']-agg['acc_null']:+.3f}   (>0 且越大 ⇒ 答案确来自板)")
        return

    with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
        for s in samples[:8]:
            ctx, q, a = s["context"], s["question"], s["answer"]
            board_ctx = board_of_context(model, tok.encode(ctx).ids, device)
            qa_prefix = tok.encode(f"用户\n{q}\n助手\n").ids
            full_prefix = tok.encode(f"{ctx}\n用户\n{q}\n助手\n").ids
            g_board = generate_given(model, board_ctx, qa_prefix, args.max_new_tokens, args.seg_len, eos_id, device)
            g_none = generate_given(model, None, qa_prefix, args.max_new_tokens, args.seg_len, eos_id, device)
            g_full = generate_given(model, None, full_prefix, args.max_new_tokens, args.seg_len, eos_id, device)
            print("=" * 64)
            print(f"上下文: {ctx}")
            print(f"问题: {q}  | 参考: {a}")
            print(f"[板+问题 board] {tok.decode(g_board)}")
            print(f"[只问题  none ] {tok.decode(g_none)}")
            print(f"[全文本  full ] {tok.decode(g_full)}")


if __name__ == "__main__":
    main()
