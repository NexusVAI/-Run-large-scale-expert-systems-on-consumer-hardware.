# Blackboard Relay: Cooperative Small Language Models via Compressed Latent-State Hand-off

Code and paper for **Blackboard Relay (BRP)** — a study of whether small language
models can cooperate by handing off a *compressed hidden state* (a fixed-size
"blackboard" tensor `B ∈ R^{M×d}`, `M=32`) instead of text.

Base model: **Cancri-500M** (board-native decoder, `M=32`, `d=1536`), by NexusVAI.

> **Scope.** Experiments use a controllable *synthetic* multi-clue benchmark
> (attribute lookup + two-hop join). The architectural conclusions
> (cross-weight latent alignment, specialization gain) are supported; the
> *magnitude* of "board beats full-text" is task-dependent and should not be
> extrapolated to open-domain tasks. See the Limitations section of the paper.

## Paper

`paper/paper.pdf` (source: `paper/paper.tex`). Build:

```bash
cd paper
python3 make_figs.py            # regenerate fig_curves.pdf, fig_bars.pdf
pdflatex paper.tex && pdflatex paper.tex
```

## Headline result

Held-out exact-answer accuracy (empty-board control in parentheses):

| Configuration                  | board relay | full-text | null (empty board) |
|--------------------------------|:-----------:|:---------:|:------------------:|
| Cancri-500M (zero-shot)        | 0.150       | 0.455     | 0.000              |
| Single weight (relay-finetuned)| 0.610       | 0.575     | 0.085              |
| **Dual weight (U + A)**        | **0.859**   | 0.625     | 0.172              |

Two experts forked from the shared base — an *Understand* expert that writes the
board and an *Answer* expert that reads it — co-trained through the board reach
**0.86**, beating both a single weight in both roles (0.61) and feeding the full
context as text (0.62), while the empty-board control stays low (0.17).

## Chat with the model

```bash
# interactive multi-turn (CPU by default; add --device cuda for GPU)
python chat.py --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json -i

# single prompt
python chat.py --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json \
    --prompt "你是谁？"
```

Chat template (the format the model was aligned with):

```
用户
{user}
助手
{assistant}<|end_of_text|>
```

## Files

| File | Purpose |
|------|---------|
| `run_cancri.py`        | Cancri model definition + board-segment forward + inference |
| `chat.py`              | Multi-turn chat / single-prompt inference for the 0.5B weights |
| `cancri_relay.py`      | Latent-relay diagnostic (board-lift, pure-relay generation) |
| `cancri_relay_ft.py`   | Single-weight relay finetuning (sole-path / bypass-blocked) |
| `cancri_relay2.py`     | Board-as-augmented-state harness (board-lift / gen / exact-key acc) |
| `cancri_relay2_ft.py`  | Single-weight context→board→answer finetuning |
| `cancri_brp_dual.py`   | **Dual-weight** trainer (U writes board, A reads it), with a gradient-connectivity check |
| `make_relay_charts.py` | Training-curve / summary charts |
| `paper/`               | LaTeX source, figures, compiled PDF |

## Reproduce

Requires the released `Cancri-500M` checkpoint (`cancri_500m_dpo6.ckpt`) and the
matching 32k BPE `tokenizer.json`.

```bash
# Dual-weight latent-relay training (Understand + Answer experts)
python cancri_brp_dual.py --mode run --device cuda --dtype bfloat16 \
  --base cancri_500m_dpo6.ckpt --tokenizer tokenizer.json --synth-n 20000 \
  --out-u expert_understand.ckpt --out-a expert_answer.ckpt \
  --out-csv brp_dual_log.csv --epochs 3 --lr 1e-5

# Three-way control on a held-out generation seed (board / null / full-text)
python cancri_relay2.py --mode acc --device cuda --dtype bfloat16 \
  --ckpt cancri_500m_relay2.ckpt.best --tokenizer tokenizer.json \
  --limit 200 --gen-seed 999
```

The multi-clue benchmark is generated procedurally with a fixed seed; no external
data is required.

## Citation

```bibtex
@techreport{gu2026blackboardrelay,
  title  = {Blackboard Relay: Cooperative Small Language Models via Compressed Latent-State Hand-off},
  author = {Gu, Xingyu},
  institution = {NexusVAI},
  year   = {2026}
}
```
