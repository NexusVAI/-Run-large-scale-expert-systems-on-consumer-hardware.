import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "DejaVu Sans"

# relay2-ft（单权重）acc 曲线
s1 = [0, 1, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2400,
      2600, 2800, 3000, 3200, 3400, 3600, 3738]
acc1 = [0.094, 0.094, 0.594, 0.594, 0.594, 0.594, 0.594, 0.578, 0.625, 0.609,
        0.609, 0.609, 0.609, 0.625, 0.609, 0.625, 0.625, 0.609, 0.625, 0.625, 0.609]

# brp_dual（双权重）
s2 = [0, 1, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2400,
      2600, 2800, 3000, 3200, 3400, 3600, 3738]
b = [0.141, 0.156, 0.672, 0.734, 0.703, 0.750, 0.828, 0.812, 0.828, 0.812, 0.844,
     0.812, 0.828, 0.859, 0.859, 0.859, 0.859, 0.859, 0.859, 0.859, 0.859]
n = [0.016, 0.016, 0.188, 0.156, 0.125, 0.109, 0.188, 0.203, 0.141, 0.156, 0.094,
     0.094, 0.156, 0.156, 0.156, 0.156, 0.172, 0.172, 0.172, 0.172, 0.172]
f = [0.500, 0.516, 0.656, 0.641, 0.594, 0.594, 0.594, 0.609, 0.609, 0.609, 0.625,
     0.609, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625]

fig, ax = plt.subplots(1, 2, figsize=(13, 4.6))

ax[0].plot(s1, acc1, "-o", ms=3, color="#c0392b", label="acc (board relay)")
ax[0].axhline(0.094, ls="--", c="gray", lw=1, label="init 0.094")
ax[0].set_title("Single-weight relay2-ft: exact-key acc")
ax[0].set_xlabel("step"); ax[0].set_ylabel("accuracy"); ax[0].set_ylim(0, 1)
ax[0].grid(alpha=0.3); ax[0].legend(loc="lower right")

ax[1].plot(s2, b, "-o", ms=3, color="#1f78b4", label="acc_board (U write / A read)")
ax[1].plot(s2, f, "-s", ms=3, color="#33a02c", label="acc_full (full-text baseline)")
ax[1].plot(s2, n, "-^", ms=3, color="#999999", label="acc_null (empty board)")
ax[1].set_title("Dual-weight BRP: cross-weight latent relay")
ax[1].set_xlabel("step"); ax[1].set_ylabel("accuracy"); ax[1].set_ylim(0, 1)
ax[1].grid(alpha=0.3); ax[1].legend(loc="center right")

fig.tight_layout()
fig.savefig("relay_acc_curves.png", dpi=130)
fig.savefig("paper/relay_acc_curves.pdf")
print("saved relay_acc_curves.png/pdf")

# 汇总柱状图：四配置 board vs null vs full
fig2, ax2 = plt.subplots(figsize=(8, 4.6))
cfgs = ["dpo6\n(zero-shot)", "single\nrelay2-ft", "dual\nU+A"]
board = [0.150, 0.610, 0.859]
null = [0.000, 0.085, 0.172]
full = [0.455, 0.575, 0.625]
x = range(len(cfgs))
w = 0.26
ax2.bar([i - w for i in x], board, w, label="board relay", color="#1f78b4")
ax2.bar(list(x), full, w, label="full-text", color="#33a02c")
ax2.bar([i + w for i in x], null, w, label="null (empty board)", color="#999999")
ax2.set_xticks(list(x)); ax2.set_xticklabels(cfgs)
ax2.set_ylabel("exact-key accuracy"); ax2.set_ylim(0, 1)
ax2.set_title("Latent relay vs full-text vs null (gen-seed held-out)")
for i in x:
    ax2.text(i - w, board[i] + 0.02, f"{board[i]:.2f}", ha="center", fontsize=8)
    ax2.text(i, full[i] + 0.02, f"{full[i]:.2f}", ha="center", fontsize=8)
ax2.grid(alpha=0.3, axis="y"); ax2.legend()
fig2.tight_layout()
fig2.savefig("relay_summary_bars.png", dpi=130)
fig2.savefig("paper/relay_summary_bars.pdf")
print("saved relay_summary_bars.png/pdf")
