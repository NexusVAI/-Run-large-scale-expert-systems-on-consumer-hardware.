#!/usr/bin/env python3
"""Cancri 隐状态多专家接力 (latent blackboard relay) —— 第一步 harness。

核心：专家之间只传黑板张量 board [B,M,d]，不落文字。
  - 上游专家读问题 → forward_segment(with_write=True) → board_A
  - 中游专家读 board_A（+ 角色提示段）→ board_B
  - 下游专家读 board_B → 生成答案 / 评 PPL
全部专家当前 = 同一份权重（dpo6）戴不同角色帽子（role prefix）。真正分叉留 Stage 2；
本脚本先把 latent relay 管线 + board 读写 + 诊断指标立住（对应文档 Stage 3 "在自己模型上复跑 relay"）。

诊断指标（对齐 cancri_stage1_pretrain.eval_lift / 论文 board_lift vs LM drift 框架）：
  ppl_null  : 答案在「空板 board0」下的 PPL（下界，下游没拿到任何上游信息）
  ppl_real  : 答案在「接力板 board_relay」下的 PPL（待测：latent 板是否携带了问题信息）
  ppl_inline: 答案在「问题以文字直接同段前置」下的 PPL（上界，旁路=直接看原文）
  board_lift = ppl_null - ppl_real          >0 ⇒ 下游确实读了上游写的板
  recovery   = (ppl_null - ppl_real)/(ppl_null - ppl_inline)   ~1 ⇒ 板补回≈全部旁路价值

用法（MI300X，bf16；模型 = 已对齐的 dpo6）：
  # 定量：latent 板到底有没有用
  python -u -X utf8 cancri_relay.py --mode board-lift --device cuda --dtype bfloat16 \
    --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json --data relay_eval.jsonl
  # 定性：接力 vs 直答，人眼对比
  python -u -X utf8 cancri_relay.py --mode gen --device cuda --dtype bfloat16 \
    --ckpt cancri_500m_dpo6.ckpt --tokenizer tokenizer.json
  # CPU 冒烟（随机小模型，只验管线/形状，不看质量）
  python -X utf8 cancri_relay.py --mode smoke
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from tokenizers import Tokenizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_cancri import CancriGPT, _sample_logits  # noqa: E402

PAD_ID = 2
IGN = -100

# ── 角色帽子（单权重零样本；真正专精留 Stage 2 分叉）──
# 每个 relay 阶段 = 一段 [role_prefix + content]，从上一阶段的 board 续算、写出新 board。
ROLE_UNDERSTAND = "用户\n{q}\n助手\n"          # 上游：读题
ROLE_REASON = "（先在心里理清题目要点与步骤）\n"   # 中游：精炼板（无新文字内容，纯多一跳）
ROLE_ANSWER = "用户\n{q}\n助手\n"              # 下游答案段的可见前缀（board-lift 里答案计分只在 answer 段）

# 定性内置题（多跳/身份/安全各覆盖一点）
DEMO_QA = [
    "小明有12个苹果，给了小红5个，又买了8个，现在有几个？请一步步算。",
    "一个长方形长9米，宽4米，周长和面积各是多少？",
    "为什么天空是蓝色的？",
    "你是谁？",
]

# 定量内置集（无 --data 时用；answer 为参考答案，用来算板对答案预测的增益）
DEMO_EVAL = [
    {"question": "小明有12个苹果，给了小红5个，又买了8个，现在有几个？",
     "answer": "小明现在有15个苹果。先12减5等于7，再7加8等于15。"},
    {"question": "一个长方形长9米，宽4米，周长是多少？",
     "answer": "周长是26米，等于（9加4）乘2。"},
    {"question": "光合作用把什么转化为什么？",
     "answer": "光合作用把二氧化碳和水在光能下转化为有机物并释放氧气。"},
]


def encode(tok, text):
    return tok.encode(text).ids


def to_seg(ids, device):
    return torch.tensor(ids, dtype=torch.long, device=device).unsqueeze(0)


@torch.no_grad()
def relay_board(model, stage_segs, device):
    """按序把 stage_segs 里每段喂进去，段间只传 board（latent 接力）。返回最终 board [1,M,d]。"""
    board = model.board0_batch(1)
    for ids in stage_segs:
        if not ids:
            continue
        _, board = model.forward_segment(to_seg(ids, device), board, with_write=True)
    return board


@torch.no_grad()
def answer_ce(model, board_in, answer_ids, device):
    """答案段在给定 board 下的平均 CE（黑板路径，无 shift：logits[i] 预测 token i）。"""
    seg = to_seg(answer_ids, device)
    logits, _ = model.forward_segment(seg, board_in, with_write=False)
    logits = logits[0].float()                       # [S,V]
    tgt = seg[0]                                      # [S]
    return F.cross_entropy(logits, tgt).item()


@torch.no_grad()
def inline_ce(model, question_ids, answer_ids, device):
    """上界：问题以文字直接同段前置，只在答案 token 上计分（旁路=直接看原文）。"""
    full = question_ids + answer_ids
    seg = to_seg(full, device)
    board0 = model.board0_batch(1)
    logits, _ = model.forward_segment(seg, board0, with_write=False)
    logits = logits[0].float()
    tgt = seg[0]
    qn = len(question_ids)
    ans_logits = logits[qn:qn + len(answer_ids)]      # 只取答案段
    ans_tgt = tgt[qn:qn + len(answer_ids)]
    return F.cross_entropy(ans_logits, ans_tgt).item()


def board_lift_eval(model, tok, samples, device, hops):
    """对每条 {question, answer} 算 ppl_null / ppl_real / ppl_inline + board_lift。"""
    rows = []
    ce_null, ce_real, ce_inline = [], [], []
    for s in samples:
        q, a = s["question"], s["answer"]
        q_ids = encode(tok, ROLE_UNDERSTAND.format(q=q))
        a_ids = encode(tok, a)
        # 接力构板：理解 → (可选)推理跳 → 得 board_relay
        stages = [encode(tok, ROLE_UNDERSTAND.format(q=q))]
        for _ in range(max(0, hops - 1)):
            stages.append(encode(tok, ROLE_REASON))
        board_relay = relay_board(model, stages, device)
        board0 = model.board0_batch(1)

        c_null = answer_ce(model, board0, a_ids, device)
        c_real = answer_ce(model, board_relay, a_ids, device)
        c_inline = inline_ce(model, q_ids, a_ids, device)
        ce_null.append(c_null); ce_real.append(c_real); ce_inline.append(c_inline)
        rows.append((q[:24], math.exp(c_null), math.exp(c_real), math.exp(c_inline)))

    mean = lambda xs: sum(xs) / len(xs)
    ppl_null, ppl_real, ppl_inline = map(lambda xs: math.exp(mean(xs)), (ce_null, ce_real, ce_inline))
    lift = ppl_null - ppl_real
    denom = ppl_null - ppl_inline
    rec = lift / denom if abs(denom) > 1e-6 else float("nan")
    return rows, dict(ppl_null=ppl_null, ppl_real=ppl_real, ppl_inline=ppl_inline,
                      board_lift=lift, recovery=rec)


@torch.no_grad()
def generate_from_board(model, board_in, prompt_ids, max_new_tokens, seg_len, tok, eos_id, device,
                        temperature=0.7, top_p=0.9, rep=1.15):
    """从给定 board 起、以 prompt_ids 为可见前缀，黑板分段生成。board_in=None ⇒ board0（直答基线）。"""
    board = model.board0_batch(1) if board_in is None else board_in
    seg = torch.full((seg_len,), PAD_ID, dtype=torch.long, device=device)
    seg_pos = 0
    history = []
    generated = []

    def commit():
        nonlocal board, seg, seg_pos
        _, board = model.forward_segment(seg.unsqueeze(0), board, with_write=True)
        seg = torch.full((seg_len,), PAD_ID, dtype=torch.long, device=device)
        seg_pos = 0

    def ingest(tid):
        nonlocal seg_pos
        seg[seg_pos] = tid
        seg_pos += 1
        history.append(tid)
        if seg_pos >= seg_len:
            commit()

    for tid in prompt_ids:
        ingest(tid)
    for _ in range(max_new_tokens):
        logits, _ = model.forward_segment(seg.unsqueeze(0), board, with_write=False)
        nl = logits[0, seg_pos].clone()
        if rep != 1.0:
            for tid in set(history[-256:]):
                nl[tid] = nl[tid] / rep if nl[tid] > 0 else nl[tid] * rep
        nid = _sample_logits(nl, temperature, 0, top_p)
        if eos_id is not None and nid == eos_id:
            break
        generated.append(nid)
        ingest(nid)
    return generated


def build_model(ckpt_path, device):
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    model = CancriGPT(
        vocab=cfg["vocab"], d_model=cfg["d_model"], n_layer=cfg["n_layer"],
        n_head=cfg["n_head"], n_kv_head=cfg["n_kv_head"], inter=cfg["intermediate"],
        rope_theta=cfg["rope_theta"], m=cfg["m"], rms_eps=cfg["rms_eps"],
    )
    model.load_state_dict(ck["model"])
    return model.to(device).eval(), cfg


def load_eval(path):
    out = []
    op = __import__("gzip").open if path.endswith(".gz") else open
    with op(path, "rt", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            o = json.loads(line)
            q = o.get("question") or o.get("q")
            a = o.get("answer") or o.get("a")
            if q and a:
                out.append({"question": q, "answer": a})
    return out


def run_smoke():
    """CPU 随机小模型：只验 relay 管线 + 形状 + board_lift 不报错（不看质量）。"""
    torch.manual_seed(0)
    device = torch.device("cpu")
    model = CancriGPT(vocab=300, d_model=64, n_layer=2, n_head=4, n_kv_head=2,
                      inter=128, rope_theta=500000.0, m=8, rms_eps=1e-6).to(device).eval()

    class FakeTok:
        def encode(self, t):
            class E: ...
            e = E(); e.ids = [(ord(c) % 290) + 5 for c in t][:40] or [5]
            return e
        def decode(self, ids): return "".join(chr(65 + (i % 26)) for i in ids)
        def token_to_id(self, t): return 3
    tok = FakeTok()

    board = relay_board(model, [tok.encode("理解 问题").ids, tok.encode("推理").ids], device)
    assert board.shape == (1, model.M, model.d), board.shape
    rows, agg = board_lift_eval(model, tok, DEMO_EVAL, device, hops=2)
    assert set(agg) >= {"ppl_null", "ppl_real", "ppl_inline", "board_lift", "recovery"}
    gen = generate_from_board(model, board, tok.encode("答案").ids, 8, 64, tok, 3, device)
    assert isinstance(gen, list)
    # 直答基线（board_in=None）也要能跑
    _ = generate_from_board(model, None, tok.encode("答案").ids, 8, 64, tok, 3, device)
    print("[smoke] relay 管线 OK：board", tuple(board.shape),
          "| board_lift", round(agg["board_lift"], 4), "| gen_len", len(gen))
    print("[smoke] 各样本 ppl(null/real/inline):")
    for q, n, r, i in rows:
        print(f"   {q:<24} {n:8.2f} {r:8.2f} {i:8.2f}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", default="board-lift", choices=["board-lift", "gen", "smoke"])
    p.add_argument("--ckpt")
    p.add_argument("--tokenizer")
    p.add_argument("--data", default="", help="board-lift 用的 jsonl：{question, answer} 每行一条")
    p.add_argument("--device", default="cuda", choices=["cpu", "cuda"])
    p.add_argument("--dtype", default="bfloat16", choices=["float32", "bfloat16"])
    p.add_argument("--hops", type=int, default=2, help="relay 跳数（≥1）：1=只理解段，2=加一跳推理精炼")
    p.add_argument("--seg-len", type=int, default=512)
    p.add_argument("--max-new-tokens", type=int, default=160)
    p.add_argument("--pure-relay", action="store_true",
                   help="gen 纯净接力：答案段只可见「助手」标记，问题只活在 latent 板里"
                        "（隔离测试 latent 板能否单独驱动生成，不靠答案段再看一遍原文）")
    args = p.parse_args()

    if args.mode == "smoke":
        run_smoke()
        return

    if not args.ckpt or not args.tokenizer:
        raise SystemExit("--mode board-lift/gen 需要 --ckpt 和 --tokenizer")

    device = torch.device(args.device if (args.device == "cpu" or torch.cuda.is_available()) else "cpu")
    dtype = torch.bfloat16 if (args.dtype == "bfloat16" and device.type == "cuda") else torch.float32
    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id("<|end_of_text|>")
    model, cfg = build_model(args.ckpt, device)
    if dtype == torch.bfloat16:
        model = model.to(dtype=torch.bfloat16)
    print(f"已加载 {args.ckpt} | M={cfg['m']} d={cfg['d_model']} | device={device} dtype={dtype} | hops={args.hops}")

    if args.mode == "board-lift":
        samples = load_eval(args.data) if args.data else DEMO_EVAL
        print(f"评测样本 {len(samples)} 条")
        with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
            rows, agg = board_lift_eval(model, tok, samples, device, args.hops)
        print(f"\n{'问题':<26}{'ppl_null':>10}{'ppl_real':>10}{'ppl_inline':>12}")
        for q, n, r, i in rows:
            print(f"{q:<26}{n:>10.2f}{r:>10.2f}{i:>12.2f}")
        print("\n=== 汇总 ===")
        print(f"  ppl_null (空板下界)   : {agg['ppl_null']:.3f}")
        print(f"  ppl_real (接力板)     : {agg['ppl_real']:.3f}")
        print(f"  ppl_inline (文字上界) : {agg['ppl_inline']:.3f}")
        print(f"  board_lift = null-real: {agg['board_lift']:+.3f}   (>0 ⇒ 下游读到了上游写的 latent 板)")
        print(f"  recovery              : {agg['recovery']:.3f}   (~1 ⇒ latent 板≈补回全部旁路价值)")
        return

    # gen：接力 vs 直答
    with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
        for q in DEMO_QA:
            stages = [encode(tok, ROLE_UNDERSTAND.format(q=q))]
            for _ in range(max(0, args.hops - 1)):
                stages.append(encode(tok, ROLE_REASON))
            board_relay = relay_board(model, stages, device)
            # 纯净接力：答案段不再重复问题文字，latent 板是唯一信息源；否则问题=板+文字双喂
            relay_prefix = encode(tok, "助手\n") if args.pure_relay else encode(tok, ROLE_ANSWER.format(q=q))
            direct_prefix = encode(tok, ROLE_ANSWER.format(q=q))
            g_relay = generate_from_board(model, board_relay, relay_prefix, args.max_new_tokens,
                                          args.seg_len, tok, eos_id, device)
            g_direct = generate_from_board(model, None, direct_prefix, args.max_new_tokens,
                                           args.seg_len, tok, eos_id, device)
            print("=" * 64)
            print(f"Q: {q}")
            print(f"[接力 relay] {tok.decode(g_relay)}")
            print(f"[直答 direct] {tok.decode(g_direct)}")


if __name__ == "__main__":
    main()
