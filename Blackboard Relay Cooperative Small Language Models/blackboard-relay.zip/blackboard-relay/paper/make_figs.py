import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Nimbus Roman", "Times New Roman", "DejaVu Serif"],
    "font.size": 11,
    "axes.titlesize": 11,
    "legend.fontsize": 9,
    "axes.linewidth": 0.8,
})

steps = [0, 1, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200,
         2400, 2600, 2800, 3000, 3200, 3400, 3600, 3738]
acc1 = [0.094, 0.094, 0.594, 0.594, 0.594, 0.594, 0.594, 0.578, 0.625, 0.609,
        0.609, 0.609, 0.609, 0.625, 0.609, 0.625, 0.625, 0.609, 0.625, 0.625, 0.609]
b = [0.141, 0.156, 0.672, 0.734, 0.703, 0.750, 0.828, 0.812, 0.828, 0.812, 0.844,
     0.812, 0.828, 0.859, 0.859, 0.859, 0.859, 0.859, 0.859, 0.859, 0.859]
n = [0.016, 0.016, 0.188, 0.156, 0.125, 0.109, 0.188, 0.203, 0.141, 0.156, 0.094,
     0.094, 0.156, 0.156, 0.156, 0.156, 0.172, 0.172, 0.172, 0.172, 0.172]
f = [0.500, 0.516, 0.656, 0.641, 0.594, 0.594, 0.594, 0.609, 0.609, 0.609, 0.625,
     0.609, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625, 0.625]

# Fig 1: training curves (two panels)
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.7))
ax[0].plot(steps, acc1, "-o", ms=2.5, lw=1.3, color="#c0392b", label="board relay")
ax[0].axhline(0.094, ls="--", c="0.5", lw=0.9, label="init (0.094)")
ax[0].set_title("(a) Single weight (shared U/A)")
ax[0].set_xlabel("training step"); ax[0].set_ylabel("exact-answer acc.")
ax[0].set_ylim(0, 1); ax[0].grid(alpha=0.3, lw=0.5); ax[0].legend(loc="lower right", frameon=False)

ax[1].plot(steps, b, "-o", ms=2.5, lw=1.3, color="#1f78b4", label=r"board ($U\!\to\!A$)")
ax[1].plot(steps, f, "-s", ms=2.5, lw=1.3, color="#33a02c", label="full-text")
ax[1].plot(steps, n, "-^", ms=2.5, lw=1.3, color="#8a8a8a", label="null (empty board)")
ax[1].set_title("(b) Dual weight (specialized U, A)")
ax[1].set_xlabel("training step"); ax[1].set_ylabel("exact-answer acc.")
ax[1].set_ylim(0, 1); ax[1].grid(alpha=0.3, lw=0.5); ax[1].legend(loc="center right", frameon=False)
fig.tight_layout()
fig.savefig("fig_curves.pdf")

# Fig 2: summary bars
fig2, ax2 = plt.subplots(figsize=(3.4, 2.7))
cfgs = ["dpo6\n(0-shot)", "single", "dual"]
board = [0.150, 0.610, 0.859]
null = [0.000, 0.085, 0.172]
full = [0.455, 0.575, 0.625]
x = range(len(cfgs)); w = 0.27
ax2.bar([i - w for i in x], board, w, label="board relay", color="#1f78b4")
ax2.bar(list(x), full, w, label="full-text", color="#33a02c")
ax2.bar([i + w for i in x], null, w, label="null", color="#8a8a8a")
ax2.set_xticks(list(x)); ax2.set_xticklabels(cfgs)
ax2.set_ylabel("exact-answer acc."); ax2.set_ylim(0, 1)
for i in x:
    ax2.text(i - w, board[i] + 0.02, f"{board[i]:.2f}", ha="center", fontsize=7.5)
ax2.grid(alpha=0.3, axis="y", lw=0.5); ax2.legend(frameon=False, loc="upper left")
fig2.tight_layout()
fig2.savefig("fig_bars.pdf")
print("figs done")
