#!/usr/bin/env python3
"""Cancri 上下文-relay 微调 —— 把"板能传上下文"(dpo6 已 recovery 0.85)训成"能从板正确作答"。

对齐 relay2 的推理形态（板=附加状态，问题文本可见）：
  上游读【上下文】→ board_ctx
  下游【问题文本(精确) + board_ctx(压缩上下文)】→ 作答
  loss = CE(answer | 问题文本, board_ctx)   （teacher forcing，只在答案 token 计分）

为什么这样练能行（relay2 诊断已证）：dpo6 零样本时 board_lift=+8.76/recovery=0.85 —— 板**已经**
把多线索上下文的信息传过去了(PPL 层面)，缺的只是"把板解码成正确答案"的能力。这脚本就补这个。

board-dropout：以一定概率把 board_ctx 换 board0（= 没上下文）→ 逼模型"没线索时别乱编"，
  并防止它忽略问题文本。默认 0.15。

数据：默认用内置多线索合成集（--synth-n 条，属性反查+两跳 join）；也可 --data 传 {context,question,answer[,key]}。

用法：
  python -u -X utf8 cancri_relay2_ft.py --mode run --device cuda --dtype bfloat16 \
    --base cancri_500m_dpo6.ckpt --tokenizer tokenizer.json --synth-n 20000 \
    --out cancri_500m_relay2.ckpt --out-csv relay2_ft_log.csv --epochs 3 --lr 1e-5
  python -X utf8 cancri_relay2_ft.py --mode smoke
"""
from __future__ import annotations

import argparse
import csv
import gzip
import json
import math
import random
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from tokenizers import Tokenizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_cancri import CancriGPT, _sample_logits  # noqa: E402
from cancri_relay2 import gen_synth  # noqa: E402  （复用合成器，含 key）

PAD_ID = 2
IGN = -100


def encode_sample(tok, s, eos_id, max_ctx, max_a):
    ctx_ids = tok.encode(s["context"]).ids
    head = tok.encode(f"用户\n{s['question']}\n助手\n").ids
    ans = tok.encode(s["answer"]).ids + [eos_id]
    if len(ctx_ids) > max_ctx or len(head) + len(ans) > max_a:
        return None
    down = head + ans
    lab = [IGN] * len(head) + ans
    return ctx_ids, down, lab, s.get("key", s["answer"])


def load_samples(args, tok, eos_id):
    if args.data:
        raw = []
        op = gzip.open if str(args.data).endswith(".gz") else open
        with op(args.data, "rt", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    o = json.loads(line)
                    if o.get("context") and o.get("question") and o.get("answer"):
                        raw.append(o)
    else:
        raw = gen_synth(args.synth_n, seed=args.seed)
    out = []
    for s in raw:
        e = encode_sample(tok, s, eos_id, args.max_ctx, args.max_a)
        if e:
            out.append(e)
    return out


def pad(seqs, fill, device):
    S = max(len(s) for s in seqs)
    t = torch.full((len(seqs), S), fill, dtype=torch.long)
    for i, s in enumerate(seqs):
        t[i, :len(s)] = torch.tensor(s, dtype=torch.long)
    return t.to(device)


def relay2_logits(model, ctx, down, board_dropout=0.0):
    """上游读 ctx → board_ctx；下游读 down（问题+答案文本）在 board_ctx 下 → 答案段 logits。"""
    B = ctx.size(0)
    board0 = model.board0_batch(B)
    _, board_ctx = model.forward_segment(ctx, board0, with_write=True)
    if board_dropout > 0:
        mask = (torch.rand(B, 1, 1, device=ctx.device) < board_dropout).float()
        board_ctx = mask * model.board0_batch(B) + (1.0 - mask) * board_ctx
    logits, _ = model.forward_segment(down, board_ctx, with_write=False)
    return logits


def relay2_loss(model, ctx, down, lab, board_dropout=0.0):
    logits = relay2_logits(model, ctx, down, board_dropout)
    logp = F.log_softmax(logits.float(), dim=-1)
    tok_logp = logp.gather(-1, down.unsqueeze(-1)).squeeze(-1)
    mask = (lab != IGN).float()
    return -(tok_logp * mask).sum() / mask.sum().clamp(min=1.0)


@torch.no_grad()
def eval_metrics(model, samples, tok, device, eos_id, n=64):
    """board_lift（none/board）+ 生成 exact-key 准确率（board 条件下贪心答对率）。"""
    model.eval()
    p_dtype = next(model.parameters()).dtype
    ac = torch.autocast(device.type, dtype=p_dtype, enabled=(p_dtype == torch.bfloat16))
    ce_none, ce_board, hit = [], [], 0
    tot = 0
    with ac:
        for ctx_ids, down, lab, key in samples[:n]:
            c = torch.tensor(ctx_ids, dtype=torch.long, device=device).unsqueeze(0)
            d = torch.tensor(down, dtype=torch.long, device=device).unsqueeze(0)
            lb = torch.tensor(lab, dtype=torch.long, device=device).unsqueeze(0)
            m = (lb[0] != IGN)
            board0 = model.board0_batch(1)
            _, board_ctx = model.forward_segment(c, board0, with_write=True)
            l_board = model.forward_segment(d, board_ctx, with_write=False)[0][0].float()
            l_none = model.forward_segment(d, board0, with_write=False)[0][0].float()
            tgt = d[0][m]
            ce_board.append(F.cross_entropy(l_board[m], tgt).item())
            ce_none.append(F.cross_entropy(l_none[m], tgt).item())
            # 生成准确率：贪心从 board_ctx + 问题前缀作答，看是否命中 key
            head_len = int((lb[0] == IGN).sum().item())
            prefix = down[:head_len]
            gen = greedy_answer(model, board_ctx, prefix, 24, eos_id, device)
            if key and key in tok.decode(gen):
                hit += 1
            tot += 1
    model.train()
    mean = lambda xs: sum(xs) / len(xs)
    ppl_none, ppl_board = math.exp(mean(ce_none)), math.exp(mean(ce_board))
    return dict(ppl_none=ppl_none, ppl_board=ppl_board, board_lift=ppl_none - ppl_board,
                acc=hit / max(1, tot))


@torch.no_grad()
def greedy_answer(model, board_in, prefix_ids, max_new, eos_id, device, seg_len=512):
    board = board_in
    seg = torch.full((seg_len,), PAD_ID, dtype=torch.long, device=device)
    pos = 0
    gen = []
    for tid in prefix_ids:
        seg[pos] = tid
        pos += 1
    for _ in range(max_new):
        logits, _ = model.forward_segment(seg.unsqueeze(0), board, with_write=False)
        nid = int(logits[0, pos].argmax().item())
        if eos_id is not None and nid == eos_id:
            break
        gen.append(nid)
        seg[pos] = nid
        pos += 1
        if pos >= seg_len:
            break
    return gen


def build_model(ckpt_path, device):
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    model = CancriGPT(
        vocab=cfg["vocab"], d_model=cfg["d_model"], n_layer=cfg["n_layer"],
        n_head=cfg["n_head"], n_kv_head=cfg["n_kv_head"], inter=cfg["intermediate"],
        rope_theta=cfg["rope_theta"], m=cfg["m"], rms_eps=cfg["rms_eps"],
    )
    model.load_state_dict(ck["model"])
    return model.to(device), cfg, ck.get("step", 0)


def cosine_lr(step, total, base, warmup, min_ratio=0.1):
    if step < warmup:
        return base * step / max(1, warmup)
    p = (step - warmup) / max(1, total - warmup)
    return base * (min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * p)))


def run_smoke():
    torch.manual_seed(0)
    device = torch.device("cpu")
    model = CancriGPT(vocab=300, d_model=64, n_layer=2, n_head=4, n_kv_head=2,
                      inter=128, rope_theta=500000.0, m=8, rms_eps=1e-6).to(device)

    class FakeTok:
        def encode(self, t):
            class E: ...
            e = E(); e.ids = [(ord(c) % 290) + 5 for c in t][:60] or [5]
            return e
        def decode(self, ids): return "".join(chr(65 + (i % 26)) for i in ids)
    tok = FakeTok()
    raw = gen_synth(8, seed=1)
    samples = [encode_sample(tok, s, 3, 256, 256) for s in raw]
    samples = [s for s in samples if s]
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    model.train()
    l0 = None
    for _ in range(20):
        b = samples[:4]
        c = pad([x[0] for x in b], PAD_ID, device)
        d = pad([x[1] for x in b], PAD_ID, device)
        lab = pad([x[2] for x in b], IGN, device)
        loss = relay2_loss(model, c, d, lab, 0.15)
        opt.zero_grad(); loss.backward(); opt.step()
        if l0 is None:
            l0 = loss.item()
    met = eval_metrics(model, samples, tok, device, 3, n=8)
    assert set(met) >= {"ppl_none", "ppl_board", "board_lift", "acc"}
    print(f"[smoke] relay2-ft OK：loss {l0:.3f}→{loss.item():.3f} | "
          f"board_lift {met['board_lift']:+.3f} acc {met['acc']:.2f}（随机模型仅验管线）")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", default="run", choices=["run", "smoke"])
    p.add_argument("--base")
    p.add_argument("--tokenizer")
    p.add_argument("--data", default="", help="留空则用内置多线索合成集")
    p.add_argument("--synth-n", type=int, default=20000)
    p.add_argument("--out", default="cancri_500m_relay2.ckpt")
    p.add_argument("--out-csv", default="relay2_ft_log.csv")
    p.add_argument("--device", default="cuda", choices=["cpu", "cuda"])
    p.add_argument("--dtype", default="bfloat16", choices=["float32", "bfloat16"])
    p.add_argument("--epochs", type=float, default=3.0)
    p.add_argument("--steps", type=int, default=0)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--grad-accum", type=int, default=1)
    p.add_argument("--max-ctx", type=int, default=256)
    p.add_argument("--max-a", type=int, default=128)
    p.add_argument("--lr", type=float, default=1e-5)
    p.add_argument("--warmup-ratio", type=float, default=0.03)
    p.add_argument("--board-dropout", type=float, default=0.15)
    p.add_argument("--eval-every", type=int, default=200)
    p.add_argument("--save-every", type=int, default=1000)
    p.add_argument("--eval-n", type=int, default=64)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    if args.mode == "smoke":
        run_smoke()
        return

    if not (args.base and args.tokenizer):
        raise SystemExit("--mode run 需要 --base --tokenizer")

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(args.device if (args.device == "cpu" or torch.cuda.is_available()) else "cpu")
    dtype = torch.bfloat16 if (args.dtype == "bfloat16" and device.type == "cuda") else torch.float32
    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id("<|end_of_text|>")
    if eos_id is None:
        raise SystemExit("tokenizer 里找不到 <|end_of_text|>")

    data = load_samples(args, tok, eos_id)
    random.shuffle(data)
    if len(data) < args.batch_size + args.eval_n:
        raise SystemExit(f"样本太少：{len(data)}")
    eval_set = data[:args.eval_n]
    train = data[args.eval_n:]
    print(f"train {len(train)} | eval {len(eval_set)} | 数据源={'合成' if not args.data else args.data}")

    model, cfg, base_step = build_model(args.base, device)
    if dtype == torch.bfloat16:
        model = model.to(dtype=torch.bfloat16)
    model.train()
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.0, betas=(0.9, 0.95))

    steps_per_epoch = math.ceil(len(train) / (args.batch_size * args.grad_accum))
    total = args.steps if args.steps > 0 else int(steps_per_epoch * args.epochs)
    warmup = max(1, int(total * args.warmup_ratio))
    print(f"steps/epoch={steps_per_epoch} | total={total} | warmup={warmup} | "
          f"bpdrop={args.board_dropout} | eff_batch={args.batch_size*args.grad_accum}")

    m0 = eval_metrics(model, eval_set, tok, device, eos_id, args.eval_n)
    print(f"  [init] board_lift={m0['board_lift']:+.3f} ppl_board={m0['ppl_board']:.2f} "
          f"ppl_none={m0['ppl_none']:.2f} acc={m0['acc']:.3f}")

    csv_f = open(args.out_csv, "w", newline="", encoding="utf-8")
    cw = csv.writer(csv_f)
    cw.writerow(["step", "loss", "lr", "board_lift", "ppl_board", "ppl_none", "acc"])

    order = list(range(len(train)))
    ptr = 0

    def next_batch():
        nonlocal ptr
        if ptr + args.batch_size > len(order):
            random.shuffle(order)
            ptr = 0
        idx = order[ptr:ptr + args.batch_size]
        ptr += args.batch_size
        return [train[i] for i in idx]

    t0 = time.time()
    best = -1.0
    for step in range(1, total + 1):
        lr = cosine_lr(step, total, args.lr, warmup)
        for g in opt.param_groups:
            g["lr"] = lr
        opt.zero_grad(set_to_none=True)
        agg = 0.0
        for _ in range(args.grad_accum):
            b = next_batch()
            c = pad([x[0] for x in b], PAD_ID, device)
            d = pad([x[1] for x in b], PAD_ID, device)
            lab = pad([x[2] for x in b], IGN, device)
            with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
                loss = relay2_loss(model, c, d, lab, args.board_dropout) / args.grad_accum
            loss.backward()
            agg += loss.item()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()

        if step % args.eval_every == 0 or step == total or step == 1:
            met = eval_metrics(model, eval_set, tok, device, eos_id, args.eval_n)
            print(f"  step {step}/{total}  loss={agg:.4f}  lr={lr:.2e}  "
                  f"board_lift={met['board_lift']:+.3f}  ppl_board={met['ppl_board']:.2f}  "
                  f"acc={met['acc']:.3f}  {time.time()-t0:.0f}s", flush=True)
            cw.writerow([step, f"{agg:.4f}", f"{lr:.2e}", f"{met['board_lift']:.4f}",
                         f"{met['ppl_board']:.4f}", f"{met['ppl_none']:.4f}", f"{met['acc']:.4f}"])
            csv_f.flush()
            if met["acc"] > best:
                best = met["acc"]
                torch.save({"model": {k: v.cpu() for k, v in model.state_dict().items()},
                            "step": base_step, "cfg": cfg}, args.out + ".best")
        if args.save_every and step % args.save_every == 0:
            torch.save({"model": {k: v.cpu() for k, v in model.state_dict().items()},
                        "step": base_step, "cfg": cfg}, args.out)

    torch.save({"model": {k: v.cpu() for k, v in model.state_dict().items()},
                "step": base_step, "relay2_steps": total, "cfg": cfg}, args.out)
    csv_f.close()
    print(f"完成 {time.time()-t0:.0f}s → {args.out}（best acc={best:.3f} 存于 {args.out}.best）")


if __name__ == "__main__":
    main()
