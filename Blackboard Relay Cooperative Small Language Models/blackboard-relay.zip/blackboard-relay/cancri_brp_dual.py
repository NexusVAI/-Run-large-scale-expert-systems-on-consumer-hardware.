#!/usr/bin/env python3
"""BRP 真·双权重多专家 —— 从 dpo6 分叉出【理解专家 U】+【作答专家 A】，跨权重 relay 联合训练。

和 relay2_ft 的关键区别：那里上下游是**同一套权重**兼两角；这里是**两套独立权重**：
  理解专家 U：读【上下文】→ 写 board_ctx        （只训 U 的"写板"能力）
  作答专家 A：读【board_ctx + 问题文本】→ 作答   （只训 A 的"读板+生成"能力）
  loss = CE(answer | 问题文本, U(上下文))
  梯度经 board_ctx 同时回传 U 和 A → 逼两套权重协商出**共享的 latent 板协议**。

这正面检验文档 §7.1.1 红线：专家必须从共享基座分叉，跨权重 latent 才对齐。
判据（跨权重）：acc_board(U写A读) ≫ acc_null(A读空板) ⇒ 板协议在两套权重间真的成立。

用法：
  python -u -X utf8 cancri_brp_dual.py --mode run --device cuda --dtype bfloat16 \
    --base cancri_500m_dpo6.ckpt --tokenizer tokenizer.json --synth-n 20000 \
    --out-u expert_understand.ckpt --out-a expert_answer.ckpt \
    --out-csv brp_dual_log.csv --epochs 3 --lr 1e-5
  python -X utf8 cancri_brp_dual.py --mode smoke
"""
from __future__ import annotations

import argparse
import csv
import json
import gzip
import math
import random
import sys
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from tokenizers import Tokenizer

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_cancri import CancriGPT  # noqa: E402
from cancri_relay2 import gen_synth  # noqa: E402

PAD_ID = 2
IGN = -100


def encode_sample(tok, s, eos_id, max_ctx, max_a):
    ctx_ids = tok.encode(s["context"]).ids
    head = tok.encode(f"用户\n{s['question']}\n助手\n").ids
    ans = tok.encode(s["answer"]).ids + [eos_id]
    if len(ctx_ids) > max_ctx or len(head) + len(ans) > max_a:
        return None
    return ctx_ids, head + ans, [IGN] * len(head) + ans, s.get("key", s["answer"])


def load_samples(args, tok, eos_id):
    if args.data:
        raw = []
        op = gzip.open if str(args.data).endswith(".gz") else open
        with op(args.data, "rt", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    o = json.loads(line)
                    if o.get("context") and o.get("question") and o.get("answer"):
                        raw.append(o)
    else:
        raw = gen_synth(args.synth_n, seed=args.seed)
    out = [encode_sample(tok, s, eos_id, args.max_ctx, args.max_a) for s in raw]
    return [e for e in out if e]


def pad(seqs, fill, device):
    S = max(len(s) for s in seqs)
    t = torch.full((len(seqs), S), fill, dtype=torch.long)
    for i, s in enumerate(seqs):
        t[i, :len(s)] = torch.tensor(s, dtype=torch.long)
    return t.to(device)


def relay_dual_logits(U, A, ctx, down, board_dropout=0.0):
    """U 读 ctx → board_ctx；A 读 down（问题+答案）在 board_ctx 下 → logits。梯度回传 U 和 A。"""
    B = ctx.size(0)
    _, board_ctx = U.forward_segment(ctx, U.board0_batch(B), with_write=True)
    if board_dropout > 0:
        mask = (torch.rand(B, 1, 1, device=ctx.device) < board_dropout).float()
        board_ctx = mask * A.board0_batch(B) + (1.0 - mask) * board_ctx
    logits, _ = A.forward_segment(down, board_ctx, with_write=False)
    return logits


def relay_dual_loss(U, A, ctx, down, lab, board_dropout=0.0):
    logits = relay_dual_logits(U, A, ctx, down, board_dropout)
    logp = F.log_softmax(logits.float(), dim=-1)
    tok_logp = logp.gather(-1, down.unsqueeze(-1)).squeeze(-1)
    mask = (lab != IGN).float()
    return -(tok_logp * mask).sum() / mask.sum().clamp(min=1.0)


@torch.no_grad()
def greedy_from(A, board_in, prefix_ids, max_new, eos_id, device, seg_len=512):
    seg = torch.full((seg_len,), PAD_ID, dtype=torch.long, device=device)
    pos = 0
    gen = []
    for tid in prefix_ids:
        seg[pos] = tid
        pos += 1
    for _ in range(max_new):
        logits, _ = A.forward_segment(seg.unsqueeze(0), board_in, with_write=False)
        nid = int(logits[0, pos].argmax().item())
        if eos_id is not None and nid == eos_id:
            break
        gen.append(nid)
        seg[pos] = nid
        pos += 1
        if pos >= seg_len:
            break
    return gen


@torch.no_grad()
def eval_dual(U, A, samples, tok, device, eos_id, n=64):
    """跨权重三对照：acc_board(U写A读) / acc_null(A读A.board0) / acc_full(A读全文本)。
    samples 为编码后元组 (ctx_ids, down, lab, key)。"""
    U.eval(); A.eval()
    p_dtype = next(A.parameters()).dtype
    ac = torch.autocast(device.type, dtype=p_dtype, enabled=(p_dtype == torch.bfloat16))
    hb = hn = hf = 0
    ce_board, ce_null = [], []
    with ac:
        for ctx_ids, down_ids, lab, key in samples[:n]:
            c = torch.tensor(ctx_ids, dtype=torch.long, device=device).unsqueeze(0)
            d = torch.tensor(down_ids, dtype=torch.long, device=device).unsqueeze(0)
            lb_t = torch.tensor(lab, dtype=torch.long, device=device)
            _, board_ctx = U.forward_segment(c, U.board0_batch(1), with_write=True)
            board0 = A.board0_batch(1)
            span = (lb_t != IGN)
            tgt = d[0][span]
            lb = A.forward_segment(d, board_ctx, with_write=False)[0][0].float()
            ln = A.forward_segment(d, board0, with_write=False)[0][0].float()
            ce_board.append(F.cross_entropy(lb[span], tgt).item())
            ce_null.append(F.cross_entropy(ln[span], tgt).item())
            if key:
                head_len = int((lb_t == IGN).sum().item())
                prefix = down_ids[:head_len]
                full_prefix = ctx_ids + prefix  # 全文本对照：上下文文字直接前置
                gb = tok.decode(greedy_from(A, board_ctx, prefix, 24, eos_id, device))
                gn = tok.decode(greedy_from(A, board0, prefix, 24, eos_id, device))
                gf = tok.decode(greedy_from(A, board0, full_prefix, 24, eos_id, device))
                hb += key in gb; hn += key in gn; hf += key in gf
    U.train(); A.train()
    m = min(n, len(samples))
    mean = lambda xs: sum(xs) / len(xs)
    return dict(acc_board=hb / m, acc_null=hn / m, acc_full=hf / m,
                ppl_board=math.exp(mean(ce_board)), ppl_null=math.exp(mean(ce_null)),
                board_lift=math.exp(mean(ce_null)) - math.exp(mean(ce_board)))


def build_model(ckpt_path, device):
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
    cfg = ck["cfg"]
    m = CancriGPT(vocab=cfg["vocab"], d_model=cfg["d_model"], n_layer=cfg["n_layer"],
                  n_head=cfg["n_head"], n_kv_head=cfg["n_kv_head"], inter=cfg["intermediate"],
                  rope_theta=cfg["rope_theta"], m=cfg["m"], rms_eps=cfg["rms_eps"])
    m.load_state_dict(ck["model"])
    return m.to(device), cfg


def cosine_lr(step, total, base, warmup, min_ratio=0.1):
    if step < warmup:
        return base * step / max(1, warmup)
    p = (step - warmup) / max(1, total - warmup)
    return base * (min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * p)))


def _mk_small(device):
    return CancriGPT(vocab=300, d_model=64, n_layer=2, n_head=4, n_kv_head=2,
                     inter=128, rope_theta=500000.0, m=8, rms_eps=1e-6).to(device)


def run_smoke():
    torch.manual_seed(0)
    device = torch.device("cpu")
    U, A = _mk_small(device), _mk_small(device)

    class FakeTok:
        def encode(self, t):
            class E: ...
            e = E(); e.ids = [(ord(c) % 290) + 5 for c in t][:60] or [5]
            return e
        def decode(self, ids): return "".join(chr(65 + (i % 26)) for i in ids)
    tok = FakeTok()
    raw = gen_synth(8, seed=1)
    samples = [e for e in (encode_sample(tok, s, 3, 256, 256) for s in raw) if e]
    opt = torch.optim.AdamW(list(U.parameters()) + list(A.parameters()), lr=1e-3)
    U.train(); A.train()
    l0 = None
    for _ in range(20):
        b = samples[:4]
        c = pad([x[0] for x in b], PAD_ID, device)
        d = pad([x[1] for x in b], PAD_ID, device)
        lab = pad([x[2] for x in b], IGN, device)
        loss = relay_dual_loss(U, A, c, d, lab, 0.15)
        opt.zero_grad(); loss.backward()
        # 校验梯度确实回传到了 U（写板端）
        gu = sum(p.grad.abs().sum().item() for p in U.parameters() if p.grad is not None)
        opt.step()
        if l0 is None:
            l0 = loss.item(); assert gu > 0, "U 没收到梯度！board 未连通"
    met = eval_dual(U, A, samples, tok, device, 3, n=8)
    assert set(met) >= {"acc_board", "acc_null", "acc_full", "board_lift"}
    print(f"[smoke] BRP-dual OK：loss {l0:.3f}→{loss.item():.3f} | U 收到梯度 | "
          f"board_lift {met['board_lift']:+.3f}（随机模型仅验管线+梯度连通）")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", default="run", choices=["run", "smoke"])
    p.add_argument("--base")
    p.add_argument("--tokenizer")
    p.add_argument("--data", default="")
    p.add_argument("--synth-n", type=int, default=20000)
    p.add_argument("--out-u", default="expert_understand.ckpt")
    p.add_argument("--out-a", default="expert_answer.ckpt")
    p.add_argument("--out-csv", default="brp_dual_log.csv")
    p.add_argument("--device", default="cuda", choices=["cpu", "cuda"])
    p.add_argument("--dtype", default="bfloat16", choices=["float32", "bfloat16"])
    p.add_argument("--epochs", type=float, default=3.0)
    p.add_argument("--steps", type=int, default=0)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--grad-accum", type=int, default=1)
    p.add_argument("--max-ctx", type=int, default=256)
    p.add_argument("--max-a", type=int, default=128)
    p.add_argument("--lr", type=float, default=1e-5)
    p.add_argument("--warmup-ratio", type=float, default=0.03)
    p.add_argument("--board-dropout", type=float, default=0.15)
    p.add_argument("--eval-every", type=int, default=200)
    p.add_argument("--save-every", type=int, default=1000)
    p.add_argument("--eval-n", type=int, default=64)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    if args.mode == "smoke":
        run_smoke()
        return
    if not (args.base and args.tokenizer):
        raise SystemExit("--mode run 需要 --base --tokenizer")

    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(args.device if (args.device == "cpu" or torch.cuda.is_available()) else "cpu")
    dtype = torch.bfloat16 if (args.dtype == "bfloat16" and device.type == "cuda") else torch.float32
    tok = Tokenizer.from_file(args.tokenizer)
    eos_id = tok.token_to_id("<|end_of_text|>")
    if eos_id is None:
        raise SystemExit("tokenizer 里找不到 <|end_of_text|>")

    data = load_samples(args, tok, eos_id)
    random.shuffle(data)
    eval_set, train = data[:args.eval_n], data[args.eval_n:]
    print(f"train {len(train)} | eval {len(eval_set)} | 数据源={'合成' if not args.data else args.data}")

    # 两套独立权重，均从 dpo6 分叉
    U, cfg = build_model(args.base, device)
    A, _ = build_model(args.base, device)
    if dtype == torch.bfloat16:
        U = U.to(dtype=torch.bfloat16); A = A.to(dtype=torch.bfloat16)
    U.train(); A.train()
    opt = torch.optim.AdamW(list(U.parameters()) + list(A.parameters()),
                            lr=args.lr, weight_decay=0.0, betas=(0.9, 0.95))

    steps_per_epoch = math.ceil(len(train) / (args.batch_size * args.grad_accum))
    total = args.steps if args.steps > 0 else int(steps_per_epoch * args.epochs)
    warmup = max(1, int(total * args.warmup_ratio))
    print(f"steps/epoch={steps_per_epoch} | total={total} | warmup={warmup} | "
          f"bpdrop={args.board_dropout} | eff_batch={args.batch_size*args.grad_accum} | 双权重")

    m0 = eval_dual(U, A, eval_set, tok, device, eos_id, args.eval_n)
    print(f"  [init] acc_board={m0['acc_board']:.3f} acc_null={m0['acc_null']:.3f} "
          f"acc_full={m0['acc_full']:.3f} board_lift={m0['board_lift']:+.3f}")

    csv_f = open(args.out_csv, "w", newline="", encoding="utf-8")
    cw = csv.writer(csv_f)
    cw.writerow(["step", "loss", "lr", "acc_board", "acc_null", "acc_full", "board_lift"])

    order = list(range(len(train)))
    ptr = 0

    def next_batch():
        nonlocal ptr
        if ptr + args.batch_size > len(order):
            random.shuffle(order); ptr = 0
        idx = order[ptr:ptr + args.batch_size]
        ptr += args.batch_size
        return [train[i] for i in idx]

    def save(u_path, a_path):
        torch.save({"model": {k: v.cpu() for k, v in U.state_dict().items()}, "cfg": cfg,
                    "role": "understand"}, u_path)
        torch.save({"model": {k: v.cpu() for k, v in A.state_dict().items()}, "cfg": cfg,
                    "role": "answer"}, a_path)

    t0 = time.time()
    best = -1.0
    for step in range(1, total + 1):
        lr = cosine_lr(step, total, args.lr, warmup)
        for g in opt.param_groups:
            g["lr"] = lr
        opt.zero_grad(set_to_none=True)
        agg = 0.0
        for _ in range(args.grad_accum):
            b = next_batch()
            c = pad([x[0] for x in b], PAD_ID, device)
            d = pad([x[1] for x in b], PAD_ID, device)
            lab = pad([x[2] for x in b], IGN, device)
            with torch.autocast(device.type, dtype=dtype, enabled=(dtype == torch.bfloat16)):
                loss = relay_dual_loss(U, A, c, d, lab, args.board_dropout) / args.grad_accum
            loss.backward()
            agg += loss.item()
        torch.nn.utils.clip_grad_norm_(list(U.parameters()) + list(A.parameters()), 1.0)
        opt.step()

        if step % args.eval_every == 0 or step == total or step == 1:
            met = eval_dual(U, A, eval_set, tok, device, eos_id, args.eval_n)
            print(f"  step {step}/{total}  loss={agg:.4f}  lr={lr:.2e}  "
                  f"acc_board={met['acc_board']:.3f}  acc_null={met['acc_null']:.3f}  "
                  f"acc_full={met['acc_full']:.3f}  {time.time()-t0:.0f}s", flush=True)
            cw.writerow([step, f"{agg:.4f}", f"{lr:.2e}", f"{met['acc_board']:.4f}",
                         f"{met['acc_null']:.4f}", f"{met['acc_full']:.4f}", f"{met['board_lift']:.4f}"])
            csv_f.flush()
            if met["acc_board"] > best:
                best = met["acc_board"]
                save(args.out_u + ".best", args.out_a + ".best")
        if args.save_every and step % args.save_every == 0:
            save(args.out_u, args.out_a)

    save(args.out_u, args.out_a)
    csv_f.close()
    print(f"完成 {time.time()-t0:.0f}s → {args.out_u} / {args.out_a}（best acc_board={best:.3f} .best）")


if __name__ == "__main__":
    main()
